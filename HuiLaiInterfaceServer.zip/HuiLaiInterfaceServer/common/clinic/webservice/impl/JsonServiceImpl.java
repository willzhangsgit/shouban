package clinic.webservice.impl;

import clinic.factory.SpringFactory;
import clinic.service.IJsonService;
import clinic.utils.DBUtils;
import clinic.utils.Util;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class JsonServiceImpl implements  IJsonService
{
	private Log log = LogFactory.getLog(JsonServiceImpl.class);
	
    public String jsonInterface(String command , String params)
	{
    	String rtn = "";
		long st = 0;
		long et = 0;
		try {
			st = System.currentTimeMillis();
			Object obj = SpringFactory.getInstance().getBean(command);
			Class[] types = new Class[] {String.class};
			Method method = obj.getClass().getMethod("run", types);
		    rtn = (String) method.invoke(obj, new Object[] {new String(params)});
		} catch(Throwable t) {
			t.printStackTrace();
			log.error(t);
		} finally {
			et = System.currentTimeMillis();
			//if ((rtn != null) && ((et-st) > 1000 || rtn.length() > 50000 ))
			InsertLog(command, params, rtn, et - st);
		}
		return rtn;
	}
	
	
	private void InsertLog(String command, String params, String rtn, long delay) {
		String cip = null;
	    String sip = null;
	    long len = 9131342518472933376L;
	    try {
	    	sip = Util.getServiceIp();
	    	cip = Util.getClientIP();
	    	if ((rtn != null) && (rtn.length() > 0)) {
	    		len = rtn.length();
	    		if (rtn.length() > 1500)
	    			rtn = rtn.substring(0, 1500);
	    	}
	    	insertLogImpl(cip, sip, command, params, rtn, delay, len);
	    } catch (Throwable t1) {
	    	t1.printStackTrace();
	    	this.log.error(t1);
	    }
	}

	private void insertLogImpl(String cip, String sip, String command, String params, String rtn, long delay, long len) {
	    Connection conn = null;
	    PreparedStatement pstmt = null;
	    String sql = null;
	    int i = 1;
	    try {
	    	conn = DBUtils.GetConn();
	    	DBUtils.BeginTrans(conn);
	    	sql = " insert into cnmia.cnm_webservice_log " +
	    		 " (id , client_ip , server_ip , servicename , params , return_val , delay , len)  " +
	    		 " values (cnmia._nextval(?) , ? , ? , ? , ? , ? , ? , ?)";
	    	pstmt = conn.prepareStatement(sql);
	    	pstmt.setString(i++, "id");
	    	pstmt.setString(i++, cip);
	    	pstmt.setString(i++, sip);
	    	pstmt.setString(i++, command);
	    	pstmt.setString(i++, params);
	    	pstmt.setString(i++, rtn);
	    	pstmt.setLong(i++, delay);
	    	pstmt.setLong(i++, len);
	    	pstmt.execute();
	    	DBUtils.Commit(conn);
	    } catch (Throwable t1) {
	    	DBUtils.RollBack(conn);
	    	t1.printStackTrace();
	    } finally { 
	    	DBUtils.closeConn(null, pstmt, conn);
	    }
	}
}
