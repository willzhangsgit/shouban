package clinic.webservice;

import org.springframework.remoting.jaxrpc.ServletEndpointSupport;

import clinic.factory.ServiceFactory;
import clinic.service.IJsonService;

public class JsonService extends ServletEndpointSupport
{
	private IJsonService service;
	
	public JsonService(){
		service = ServiceFactory.getInstance().getSogoService();
	}
	
	//����м�����нӿ����
	public String openInterface(String command , String params) 
	{
		return service.jsonInterface(command, params);
	}
}
