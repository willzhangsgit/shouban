package clinic.utils;

import org.json.JSONObject;

public class JasonParamUtil {
	/**
	 * 字符串转JSON
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public static JSONObject strToJsonObject(String json)  throws Exception{
		JSONObject rtn = null; 
		try {
			rtn = new JSONObject(json);
		} catch(Exception ex) {
			throw new Exception("JSON格式转换错误");
		}
		return rtn;
	}
	
	public static JSONObject getJasonRtn(String value , String message) {
		String json = "{\"result\":\"" + value + "\",\"errmsg\":\"" + message + "\"}";   
		return new JSONObject(json);   
	}
	
	public static String getJasonStringValue(JSONObject obj , String key , String defval , boolean isneed) throws Exception{
		String rtn = null;
		try {
			if(obj.has(key)) {
				rtn = obj.getString(key);
				if(isneed && Util.strIsNullOrEmpty(rtn))
					throw new Exception("参数值为空:" + key);
			} else {
				if(isneed)
					throw new Exception("参数不存在:" + key);
				else
					rtn = defval;
			}
		} catch(Exception ex) {
			rtn = null;
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
	
	public static int getJasonIntValue(JSONObject obj , String key , int defval , boolean isneed) throws Exception{
		int rtn = -1;
		try {
			if(obj.has(key) && obj.getString(key) != null && obj.getString(key).trim().length() > 0) {
				rtn = obj.getInt(key);
			} else {
				if(isneed)
					throw new Exception("参数不存在:" + key);
				else
					rtn = defval;
			}
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
	
	public static double getJasonDoubleValue(JSONObject obj , String key , int defval , boolean isneed) throws Exception{
		double rtn = -1;
		try {
			if(obj.has(key) && obj.getString(key) != null && obj.getString(key).trim().length() > 0) {
				rtn = obj.getDouble(key);
			} else {
				if(isneed)
					throw new Exception("参数不存在:" + key);
				else
					rtn = defval;
			}
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
}
