package clinic.utils.ftp;

public class FTPConfig {

	public String IP;
	
	public String EMRDIR; //��Ŀ¼
	
	public String BILLDIR;
	
	public String EMRPATH;
	
	public String BILLPATH;
	
	public String USER;
	
	public String PWD;
	
	public String DIAGNOSIS_PATH;
	
	public String EMR_TEMPLATE_PATH;
	
	public String BILL_TEMPLATE_PATH;
	
	public boolean USE_FTP;

	public String IPBAK; //����IP
	
	public boolean DOUBLE_BAK; //ʹ��˫��д����
	
	public void setIPBAK(String ipbak) {
		IPBAK = ipbak;
	}

	public boolean isUSE_FTP() {
		return USE_FTP;
	}

	public void setUSE_FTP(boolean use_ftp) {
		USE_FTP = use_ftp;
	}

	public String getBILL_TEMPLATE_PATH() {
		return BILL_TEMPLATE_PATH;
	}

	public void setBILL_TEMPLATE_PATH(String bill_template_path) {
		BILL_TEMPLATE_PATH = bill_template_path;
	}

	public String getBILLDIR() {
		return BILLDIR;
	}

	public void setBILLDIR(String billdir) {
		BILLDIR = billdir;
	}

	public String getBILLPATH() {
		return BILLPATH;
	}

	public void setBILLPATH(String billpath) {
		BILLPATH = billpath;
	}

	public String getEMR_TEMPLATE_PATH() {
		return EMR_TEMPLATE_PATH;
	}

	public void setEMR_TEMPLATE_PATH(String emr_template_path) {
		EMR_TEMPLATE_PATH = emr_template_path;
	}

	public String getEMRDIR() {
		return EMRDIR;
	}

	public void setEMRDIR(String emrdir) {
		EMRDIR = emrdir;
	}

	public String getEMRPATH() {
		return EMRPATH;
	}

	public void setEMRPATH(String emrpath) {
		EMRPATH = emrpath;
	}

	public String getIP() {
		return IP;
	}

	public void setIP(String ip) {
		IP = ip;
	}

	public String getDIAGNOSIS_PATH() {
		return DIAGNOSIS_PATH;
	}

	public boolean isDOUBLE_BAK() {
		return DOUBLE_BAK;
	}

	public String getIPBAK() {
		return IPBAK;
	}

	public String getPWD() {
		return PWD;
	}

	public String getUSER() {
		return USER;
	}

	public void setPWD(String pwd) {
		PWD = pwd;
	}

	public void setUSER(String user) {
		USER = user;
	}

	public void setDIAGNOSIS_PATH(String diagnosis_path) {
		DIAGNOSIS_PATH = diagnosis_path;
	}

	public void setDOUBLE_BAK(boolean double_bak) {
		DOUBLE_BAK = double_bak;
	}

}
