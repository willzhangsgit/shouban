/*
 * Created on 2005-8-6
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package clinic.utils.ftp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import clinic.entity.ftp.FILE_SYNC_STATUS;
import clinic.factory.ServiceFactory;

import sun.net.TelnetOutputStream;

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FtpUtil {
	
	private static Log log = LogFactory.getLog(FtpUtil.class);
	
	public String downloadTicketReportFile(String server, String user, String passwd, String ftp_path, String filename)
	  {
	    String rtn = "";
	    FTPClient client = new FTPClient();
	    try {
	      StringBuffer buffer = new StringBuffer();
	      client.setControlEncoding("UTF-8");
	      client.connect(server);
	      client.login(user, passwd);
	      int reply = client.getReplyCode();
	      client.setDataTimeout(12000);
	      if (!(FTPReply.isPositiveCompletion(reply))) {
	        client.disconnect();
	        throw new RuntimeException("FTP server refused connection.");
	      }
	      if (FTPReply.isPositiveCompletion(client.sendCommand("OPTS UTF8", "ON"))) 
	      {
		      InputStream stream = client.retrieveFileStream(filename);
		      BufferedReader bis = new BufferedReader(new InputStreamReader(stream));
		      String temp = "";
		      while ((temp = bis.readLine()) != null) {
		        buffer.append(temp);
		        buffer.append("\r\n");
		      }
		      bis.close();
	      }
	      rtn = buffer.toString();
	    }
	    catch (Throwable t) {
	      log.error(t.getMessage());
	      try
	      {
	        if (!(client.isConnected()))
	        	client.disconnect();
	      } catch (Throwable t1) {
	        log.error("Close FTP Server error: " + t1.getMessage());
	      }
	    }
	    finally
	    {
	      try
	      {
	        if (!(client.isConnected())) ;
	        	client.disconnect();
	      } catch (Throwable t) {
	        log.error("Close FTP Server error: " + t.getMessage());
	      }
	    }
	    return rtn; 
	 }
	
	public String downloadFile(		
			String server, 
	        String user, String passwd,
			String ftp_path,
			String filename) {
		StringBuffer buffer = null;
		MyFTP client = new MyFTP(server);
		if (true == client.isFailure)
			return "";
        try {
	        client.login(user, passwd);
	        client.binary();
	        buffer = readFile(client, ftp_path, filename);
		} catch (IOException e) {
			log.error("FtpUtil.downloadFile: read FTPData ERROR! try to read data from BakFTPData");
			try {
				client.cd("/bak");
				buffer = readFile(client, ftp_path, filename);
			} catch (Throwable t) {
				log.error("FtpUtil.downloadFile: bak FTPData read ERROR!");
			}
		} catch(Throwable t) {
			log.error("FtpUtil.downloadFile");
			
		} finally {
			try {
				client.closeServer();
			} catch(Throwable t) {
				log.error("FtpUtil.downloadFile: close FTP server ERROR!");
			}
		}
		String rtn = null==buffer?"":buffer.toString();
		return rtn;
	}
	
	/**
	 * ʵ�ְ汾��������
	 * @param server
	 * @param bak_ser
	 * @param user
	 * @param passwd
	 * @param ftp_path
	 * @param filename
	 * @param id
	 * @return
	 */
	public String downloadFile(		
			String server, 
			String bak_ser,
	        String user, 
	        String passwd,
			String ftp_path,
			String filename,
			int id) {
		return "";
	}
	
	private static StringBuffer readFile(MyFTP client, String ftp_path, String filename) throws Exception {
		StringBuffer buffer = new StringBuffer();
		client.cd(ftp_path);
        BufferedReader bis = new BufferedReader(new InputStreamReader(client.get(filename)));
        String temp = "";
        while((temp=bis.readLine())!=null) {
        	buffer.append(temp);
        	buffer.append("\r\n");
        }
        bis.close();
		return buffer;
	}

//	�ϴ��ļ�
	public int put(String fname, byte[] data, 
			String _server, 
			String _user,
			String _passwd,
			String _storePath,
			String path) {
		// TODO Auto-generated method stub
		MyFTP client = new MyFTP(_server);
		int rtn = -1;
		if (true == client.isFailure)
			return rtn;
		try{		
	        client.login(_user, _passwd);
	        client.binary();
	        rtn = (-1==writeFile(client, _storePath, path, fname, data))?FILE_SYNC_STATUS.ASYNC:FILE_SYNC_STATUS.NORMAL;	//1Ϊ���洢д��ʧ��,0Ϊ�ɹ�
	        if (true == ServiceFactory.getInstance().getFTPConfig().DOUBLE_BAK) {
	        	client.cd("/bak");
	        	rtn += (-1==writeFile(client, _storePath, path, fname, data))?2:0;	
	        	/**2Ϊ���洢д��ʧ��,0Ϊ�ɹ�
	        	 * rtn����,���Ϊ3,�������͸��洢��ʧ��,1Ϊ���洢д��ʧ��,2Ϊ���洢д��ʧ��,0Ϊ���͸��洢���ɹ�  	 
	        	**/
	        }
		}catch(Exception ex)
		{
			log.error("FtpUtil.put");
		}
		finally {
			try {
				client.closeServer();
			}
			catch (IOException ie) {
				log.error("FtpUtil.put: close FTP server ERROR!");
			}
		}
		return rtn;
	}
	
	public int putFile(String fname, byte[] data, 
			String _server, 
			String _user,
			String _passwd,
			String _storePath,
			String path) {
		// TODO Auto-generated method stub
		MyFTP client = new MyFTP(_server);
		int rtn = -1;
		if (true == client.isFailure)
			return rtn;
		try{		
	        client.login(_user, _passwd);
	        client.binary();
	        rtn = writeFile(client, _storePath, path, fname, data);
		}catch(Exception ex)
		{
			log.error("FtpUtil.putFile");
		}
		finally {
			try {
				client.closeServer();
			}
			catch (IOException ie) {
				log.error("FtpUtil.putFile: close FTP server ERROR!");
			}
		}
		return rtn;
	}
	
	private static int writeFile(MyFTP client, String storePath, String path, String fileName, byte[] data) {
		int rtn = -1;
		try {
			client.cd(storePath);
	        try {
	        	client.cd(path);
	        }catch(IOException e) {
	        	client.makeDir(path);
	        	client.cd(path);
	        }
	        TelnetOutputStream out = client.put(fileName);
	        out.write(data);
	        out.flush();
	        out.close();
	        rtn = 0;
		} catch(Throwable t) {
			log.error("FtpUtil.writeFile");
		}
		return rtn;
	}
	
}