/*
 * Created on 2006-1-13
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package clinic.utils.ftp;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sun.net.ftp.FtpClient;

/**
 * @author miya82112
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class MyFTP extends FtpClient {
	
	private static Log log = LogFactory.getLog(MyFTP.class);
	protected boolean isFailure = false;
	
	public MyFTP(String server) {
		try {
			
			this.openServer(server);
			isFailure = false;
		} catch(Throwable t) {
//			log.error("����FTP����������,�������ӱ��ݷ�����......");
//			if (-1 == convertBakIP())
			log.error("MyFTP.openServer", t);
				isFailure = true;
		}
	}
	
	static {
		defaultConnectTimeout = 2000;
	}
	
	public MyFTP() {
		
	}
	
	public MyFTP(String server, String user, String pwd) throws IOException {
			this.openServer(server);
			this.login(user, pwd);
			this.binary();
	}

	public void makeDir(String fname) {
		String command = "MKD " + fname;
		try {
			this.issueCommandCheck(command);
		} catch (IOException ie) {
			 ie.printStackTrace();
		}
	}

	public void quit() {
		String command = "quit";
		try {
			this.issueCommandCheck(command);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public boolean fileExist(String filename) {
		try {
			InputStream stream = this.get(filename);
			stream.close();
		} catch (Throwable t) {
			return false;
		}
		return true;
	}
}
