package clinic.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import org.apache.axis.MessageContext;
import org.apache.axis.transport.http.HTTPConstants;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;

public  class Util {
	
	/**
	 * xml特殊字符转换
	 * @param value
	 * @return
	 */
	public static String changeSpecialString(String value)
	{
		value = value.replaceAll("&", "&amp;");
		value = value.replaceAll("<", "&lt;");
		value = value.replaceAll(">", "&gt;");
		value = value.replaceAll("\"", "&quot;");
		value = value.replaceAll("'", "&apos;");
		return value;
	}
	
	/**
	 * 判断字符串是否为空
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public static boolean strIsNullOrEmpty(String value) throws Exception {
		boolean rtn = false;
		try {
			if(value == null)
				rtn = true;
			else if(value.trim().equals(""))
				rtn = true;
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
	
	/**
	 * 字符转日期
	 * @param date
	 * @return
	 */
	public static String DateToString(Date date)
	{
		String rtn = "";
		if(date != null)
		{
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			rtn = format.format(date);
			String time = rtn.substring(rtn.indexOf(" ") , rtn.length());
			if(time.trim().equals("00:00:00"))
				rtn = rtn.substring(0 , rtn.indexOf(" "));
		}
		else 
			rtn = "";
		return rtn;
	}
	
	/**
	 * 加密解密算法
	 * @param str
	 * @return
	 */
	public static String encrypt(String str) {
		StringBuffer newStr = new StringBuffer();
		char nKey[] = {8, 16, 24, 32, 40, 48, 56, 64, 72, 80, 88, 96, 104, 112,
				120, 128, 136, 144, 152, 160};
		for (int i = 1; i <= 20; i++) {
			if (i > str.length())
				break;
			newStr.append((char) (str.charAt(i - 1) ^ nKey[i - 1]));
		}
		return newStr.toString();
	}
	
	/**
	 * 获取节点值
	 * @param par
	 * @param xpath
	 * @param defval
	 * @return
	 * @throws Exception
	 */
	public static String getNodeValue(Node par , String xpath , String defval) throws Exception {
		String rtn = null;
		try {
			if(par == null)
				throw new Exception("���ڵ㲻��Ϊ��");
			rtn = XPathAPI.selectSingleNode(par, xpath).getNodeValue();
		} catch(Exception ex) {
			rtn = defval;
		}
		return rtn;
	}
	
	/**
	 * 获取服务器IP
	 * @return
	 */
	public static String getServiceIp() {
		String rtn = "";
	    int port = 0;
	    try
	    {
	    	MessageContext mc = MessageContext.getCurrentContext();
	    	HttpServletRequest request = (HttpServletRequest)mc.getProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST);
	    	port = request.getLocalPort();
	    	InetAddress is = InetAddress.getLocalHost();
	    	String accp_ip = is.getHostAddress();
	    	rtn = accp_ip + ":" + String.valueOf(port);
	    } catch (Exception ex) {
	    	rtn = "";
	    }
	    return rtn;
	}

	/**
	 * 获取客户端IP
	 * @return
	 */
	public static String getClientIP() {
		String rtn = "";
	    try {
	    	MessageContext mc = MessageContext.getCurrentContext();
	    	HttpServletRequest request = (HttpServletRequest)mc.getProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST);
	    	rtn = request.getRemoteAddr();
	    } catch (Throwable t1) {
	    	rtn = "";
	    	t1.printStackTrace();
	    }
	    return rtn;
	}
	
}
