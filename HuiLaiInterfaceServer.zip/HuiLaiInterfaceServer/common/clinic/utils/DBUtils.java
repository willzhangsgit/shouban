package clinic.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import clinic.factory.SpringFactory;

/**
 * 数据库
 * @author HWZ
 *
 */
public class DBUtils {
	
	/**
	 * 获取数据库连接
	 * @return
	 * @throws Exception
	 */
	public static Connection GetConn() throws Exception
	{
	 Connection conn = null;
		try
		{
			conn = SpringFactory.getInstance().getDataSource().getConnection();
			
		}catch(Exception e)
		{
			System.out.println("获取数据库连接失败" + e.getMessage());
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * 开始事务
	 * @param conn
	 * @throws Exception
	 */
	public static void BeginTrans(Connection conn) throws Exception
	{
		try
 		{
 			if(conn != null)
 				conn.setAutoCommit(false);
 		}
 		catch(Exception ex)
 		{
 			ex.printStackTrace();
 		}
	}
	
	/**
	 * 提交事务
	 * @param conn
	 */
	public static void Commit(Connection conn)
 	{
 		try
 		{
 			if(conn != null)
 				conn.commit();
 		}
 		catch(Exception ex)
 		{
 			ex.printStackTrace();
 		}
 	}
	
	/**
	 * 回滚事务
	 * @param conn
	 */
 	public static void RollBack(Connection conn)
 	{
 		try
 		{
 			if(conn != null)
 				conn.rollback();
 		}
 		catch(Exception ex)
 		{
 			ex.printStackTrace();
 		}
 	}
 	
 	/**
	 * 关闭数据库连接
	 * @param set
	 * @param stat
	 * @param conn
	 */
	public static void closeConn(ResultSet set, PreparedStatement stat, Connection conn)
	{
		try
		{
			if (set != null)
				set.close();
			if (stat != null)
				stat.close();
			if (conn != null && (!conn.isClosed()))
			{
				if(!conn.getAutoCommit())
					conn.setAutoCommit(true);
				conn.close();
			}
		}catch(SQLException e){System.out.println("Close is error" +e.getMessage());}
	}
	
	/**
	 * 获取序列号值
	 * @param conn
	 * @param seqname  序列号名字   用户.序列号名字
	 * @return
	 * @throws Exception
	 */
	public static int getNextSequenceMySQL(Connection conn , String seqname) throws Exception {
		int rtn = -1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			if(conn != null && seqname != null && seqname.trim().length() > 0) {
				sql = "SELECT HUILAI._NEXTVAL(?) AS SEQ FROM DUAL";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, seqname);
				rs = pstmt.executeQuery();
				rs.next();
				rtn = rs.getInt("SEQ");
			}
		} catch (Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	/**
	 * 获取序列号值
	 * @param conn
	 * @param seqname  序列号名字   用户.序列号名字
	 * @return
	 * @throws Exception
	 */
	public static int getNextSequenceOracle(Connection conn , String seqname) throws Exception {
		int rtn = -1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			if(conn != null && seqname != null && seqname.trim().length() > 0) {
				sql = "SELECT " + seqname + ".NEXTVAL AS SEQ FROM DUAL";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				rs.next();
				rtn = rs.getInt("SEQ");
			}
		} catch (Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	/**
	 * 获取数据库当前日期
	 * @param conn
	 * @param type  1:日期时间  2:日期 3:日期 00:00:00 4:日期 23:59:59  5:时间HH-MM-DD 6:时间HH-MM
	 * @return
	 * @throws Exception
	 */
	public static String getSysdateMySQL(Connection conn , int type) throws Exception {
		String rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			if(type == 1)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%Y-%m-%d %H:%i:%S') AS DT FROM DUAL";
			else if(type == 2)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%Y-%m-%d') AS DT FROM DUAL";
			else if(type == 3)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%Y-%m-%d 00:00:00') AS DT FROM DUAL";
			else if(type == 4)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%Y-%m-%d 23:59:59') AS DT FROM DUAL";
			else if(type == 5)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%H:%i:%S') AS DT FROM DUAL";
			else if(type == 6)
				sql = "SELECT DATE_FORMAT(SYSDATE(),'%H:%i') AS DT FROM DUAL";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			rtn = rs.getString("DT");
		} catch (Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	/**
	 * 获取数据库当前日期
	 * @param conn
	 * @param type  1:日期时间  2:日期 3:日期 00:00:00 4:日期 23:59:59  5:时间HH-MM-DD 6:时间HH-MM
	 * @return
	 * @throws Exception
	 */
	public static String getSysdateOracle(Connection conn , int type) throws Exception {
		String rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = "SELECT TO_CHAR(SYSDATE , 'YYYY-MM-DD HH24:MI:SS') AS DT FROM DUAL";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			rtn = rs.getString("DT");
		} catch (Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			closeConn(rs, pstmt, null);
		}
		return rtn;
	}
}
