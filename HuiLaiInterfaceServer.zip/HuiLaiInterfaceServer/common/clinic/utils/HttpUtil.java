package clinic.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;

public class HttpUtil {
	/**
	 * Post方式请求
	 * @param path
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String post(String path,String params) throws Exception{
		 HttpURLConnection httpConn=null;
		 BufferedReader in=null;
		 URL url = null;
		 PrintWriter ot = null;
		 StringBuffer content = null;
		 try {
			 url=new URL(path);
			 content=new StringBuffer();
			 httpConn=(HttpURLConnection)url.openConnection();
			 httpConn.setRequestMethod("POST");
			 httpConn.setDoInput(true);
			 httpConn.setDoOutput(true);
			 //utf-8
			 ot = new PrintWriter(new OutputStreamWriter(httpConn.getOutputStream(),"utf-8"));
			 ot.println(params);
			 ot.flush();
			 //读取响应
			 if(httpConn.getResponseCode()==HttpURLConnection.HTTP_OK){
				 String tempStr="";
				 //utf-8
				 in=new BufferedReader(new InputStreamReader(httpConn.getInputStream(),"utf-8"));
				 while((tempStr=in.readLine())!=null){
					 content.append(tempStr);
				 }
				 return content.toString();
			 }else{
				 throw new Exception("请求出现了问题!");
			 }
		 } catch (IOException e) {
			 e.printStackTrace();
		 }finally{
			 if(in != null)
				 in.close();
			 if(ot != null)
				 ot.close();
			 httpConn.disconnect();
		 }
		 return content.toString();
	}
	
	/**
	 * 获取POST方式过来的参数
	 * @param request
	 * @return
	 * @throws IOException 
	 */
	public static String acceptParam(HttpServletRequest request) throws IOException {
		String acceptjson = null;
		BufferedReader br = null;
		String temp; 
		try { 
			br = new BufferedReader(new InputStreamReader((ServletInputStream)request.getInputStream(),"utf-8"));  
			StringBuffer sb = new StringBuffer("");  
			while ((temp = br.readLine()) != null) 
				sb.append(temp);  
			acceptjson = sb.toString();  
		} catch (Exception e) {  
			acceptjson = null;
			e.printStackTrace();    
		} finally {
			br.close();  
		}
		return acceptjson;
	}
}
