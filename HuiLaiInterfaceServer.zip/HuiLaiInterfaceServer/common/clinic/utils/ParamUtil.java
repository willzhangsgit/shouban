package clinic.utils;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ParamUtil {
	
	public static Map<String,String> XMLsetParams(String xml)
	{
		Map<String,String> paramMap = null;
		Document doc;
		try {
			paramMap = new HashMap<String,String>();
			doc = str2Doc(xml);
			Element root = doc.getDocumentElement();
			NodeList nl= root.getChildNodes();
			for(int i=0;i<nl.getLength();i++)
			{
				Node nd = nl.item(i);
				if(nd.getNodeType()== Node.ELEMENT_NODE)
				{
					if(nd.getFirstChild()!=null)
						paramMap.put(nd.getNodeName(), nd.getFirstChild().getNodeValue());
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return paramMap;
	}
	
	public static Document str2Doc(String str) throws Exception {
		Document doc = null;
		str = str.replaceAll("&nbsp;", " ");
		ByteArrayInputStream bas = new ByteArrayInputStream(str.getBytes());
		doc = newDocumentBuilder().parse(bas);
		doc.normalize();
		return doc;
	}
	
	public static DocumentBuilder newDocumentBuilder() {
		DocumentBuilder docBuilder = null;
		System.setProperty("javax.xml.parsers.DocumentBuilderFactory",
				"org.apache.crimson.jaxp.DocumentBuilderFactoryImpl");
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		try {
			docBuilder = docBuilderFactory.newDocumentBuilder();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return docBuilder;
	}
	
	public static String getParamValue(Map<String,String> map , 
			String paramname , String defvalue , boolean notnull) throws Exception {
		String rtn = null;
		try {
			if(map.containsKey(paramname)) {		
				rtn = (String)map.get(paramname);
				if(notnull && Util.strIsNullOrEmpty(rtn)) 
					throw new Exception("����" + paramname + "ֵΪ��");
			} else { 	//û�ҵ��ڵ�
				if(notnull) 	//����Ϊ��
					throw new Exception("ȱ��" + paramname + "����");
				else 	//����Ϊ��
					rtn = defvalue;
			}
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
}
