package clinic.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import clinic.entity.Cnmia.CnmiaConfigParam;
import clinic.entity.XueTouTong.XueTouTongConfigParam;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.factory.SpringFactory;


public class BaseEntity {
	
	private static Log log = LogFactory.getLog(BaseEntity.class);
	
	public static List RsToList(ResultSet rs, Class obj,String Tname , String value) throws Exception {
		List list = new ArrayList();
		ResultSetMetaData rsm = rs.getMetaData();
		while (rs.next()) 
		{ 
			Object entity = obj.newInstance();
			for (int i = 1; i <= rsm.getColumnCount(); i++) 
			{
				//String colName = rsm.getColumnName(i);
				String colName = rsm.getColumnLabel(i);
				String methodName = "set" + colName.substring(0,1).toUpperCase() + colName.substring(1).toLowerCase();
				
				Field field = null;
				try
				{
					field=obj.getDeclaredField(colName.toLowerCase());	
				}catch(Exception e)
				{
					continue;
				}	
				if(field.getType().equals(String.class))
				{
					Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {String.class});
					method.invoke(entity, new Object[] {rs.getString(colName) });
				}
				else if(field.getType().equals(int.class))
				{
					Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {int.class});
					method.invoke(entity, new Object[] {new Integer(rs.getInt(colName)) });
				}
				else if(field.getType().equals(Integer.class))
				{
					Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {Integer.class});
					method.invoke(entity, new Object[] {new Integer(rs.getInt(colName)) });
				}
				else if(field.getType().equals(double.class))
				{
					try {
					Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {double.class});
					method.invoke(entity, new Object[] {new Double(rs.getDouble(colName))});
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				else if(field.getType().equals(Double.class))
				{
					try {
					Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {Double.class});
					method.invoke(entity, new Object[] {new Double(rs.getDouble(colName))});
					} catch(Exception e) {
						e.printStackTrace();
					}
				}
				else if(field.getType().equals(Date.class))
				{
					try {
						Method method = entity.getClass().getDeclaredMethod(methodName, new Class[] {Date.class});
						method.invoke(entity, new Object[] {rs.getTimestamp(colName) });
					} catch(Exception e)
					{
						e.printStackTrace();
					}
				}
				else if(field.getType().equals(Clob.class))
				{
					
				}
			}
			if(Tname!=null)
			{
				Method method = entity.getClass().getDeclaredMethod("set" + Tname.substring(0,1).toUpperCase() + Tname.substring(1).toLowerCase(), new Class[] {String.class});
				method.invoke(entity, new Object[] {value});
			}
			
			list.add(entity);
		}
		return list;
	}

	public static String ListToXML(List ls,String rtncode,String message) {
		StringBuffer buff = null;
		try {
			buff = new StringBuffer();
			buff.append("<?xml version=\"1.0\" encoding=\"GBK\"?>\r\n");
			buff.append("<content>\r\n");
			buff.append("<rtncode>"+rtncode+"</rtncode>\r\n");
			buff.append("<errormessage>"+message+"</errormessage>\r\n");
			if(ls!=null&&ls.size()>0)
			{
				for (int i = 0; i < ls.size(); i++) {
					Object obj = ls.get(i);
					Field fd1 = obj.getClass().getDeclaredFields()[0];
					fd1.getName();
					buff.append("<").append(obj.getClass().getName()).append(">\r\n");
					for (int j = 0; j < obj.getClass().getDeclaredFields().length; j++) 
					{
						Field fd = obj.getClass().getDeclaredFields()[j];
						String fieldname = fd.getName();
						String method_name = "get" + Character.toUpperCase(fd.getName().charAt(0)) + fd.getName().substring(1);
						Class<?>[] types = new Class[] {};
						Method method = obj.getClass().getMethod(method_name, types);
						Object ob = method.invoke(obj, null);
						if(ob instanceof Set)
						{
							Set ss = (Set)ob;
							Iterator it = ss.iterator();
							buff.append("<set>");
							while(it.hasNext())
							{
								Object obb = it.next();
								List lt = new ArrayList();
								lt.add(obb);
								ToXML(lt,buff);	
							}
							buff.append("</set>");
							continue;
						}
						String value = "";
						if (fd.getType() == int.class) {
							Integer res = (Integer) method.invoke(obj,new Object[0]);
							value = String.valueOf(res.intValue());
						}else if(fd.getType() == Integer.class) {
							Integer res = (Integer) method.invoke(obj,new Object[0]);
							value = String.valueOf(res);
						}	
						else if (fd.getType() == String.class) {
							String res = (String) method.invoke(obj, new Object[0]);
							value = res;
						} else if (fd.getType() == Double.class) {
							Double res = (Double) method.invoke(obj, new Object[0]);
							value = String.valueOf(res);
						}else if (fd.getType() == double.class) {
							Double res = (Double) method.invoke(obj, new Object[0]);
							value = String.valueOf(res.doubleValue());
						}
						else if (fd.getType() == Date.class) {
							Date res = (Date) method.invoke(obj, new Object[0]);
							value = Util.DateToString(res);
						}
						buff.append("<").append(fieldname).append(">");
						if(value == null || value.trim().equals(""))
							buff.append("");
						else
							buff.append(Util.changeSpecialString(value));
						buff.append("</").append(fieldname).append(">\r\n");
					}
					buff.append("</").append(obj.getClass().getName()).append(">\r\n");
				}
			}
			buff.append("</content>");
		} catch (Throwable t) {
			log.error("BaseEntity ListToXML is error:", t);
			buff = null;
		}
		return buff.toString();
	}
	
	public static String ToXML(List ls,StringBuffer buff) {
		try {
			if(ls!=null&&ls.size()>0)
			{
				for (int i = 0; i < ls.size(); i++) {
					Object obj = ls.get(i);
					Field fd1 = obj.getClass().getDeclaredFields()[0];
					fd1.getName();
					buff.append("<").append(obj.getClass().getName()).append(">\r\n");
					for (int j = 0; j < obj.getClass().getDeclaredFields().length; j++) 
					{
						
						Field fd = obj.getClass().getDeclaredFields()[j];
						String fieldname = fd.getName();
						String method_name = "get" + Character.toUpperCase(fd.getName().charAt(0)) + fd.getName().substring(1);
						Class[] types = new Class[] {};
						Method method = obj.getClass().getMethod(method_name, types);
						String value = "";
						if (fd.getType() == int.class) {
							Integer res = (Integer) method.invoke(obj,new Object[0]);
							value = String.valueOf(res.intValue());
						}else if(fd.getType() == Integer.class) {
							Integer res = (Integer) method.invoke(obj,new Object[0]);
							value = String.valueOf(res);
						}	
						else if (fd.getType() == String.class) {
							String res = (String) method.invoke(obj, new Object[0]);
							value = res;
						} else if (fd.getType() == Double.class) {
							Double res = (Double) method.invoke(obj, new Object[0]);
							value = String.valueOf(res);
						}else if (fd.getType() == double.class) {
							Double res = (Double) method.invoke(obj, new Object[0]);
							value = String.valueOf(res.doubleValue());
						}
						else if (fd.getType() == Date.class) {
							Date res = (Date) method.invoke(obj, new Object[0]);
							value = Util.DateToString(res);
						}
						buff.append("<").append(fieldname).append(">");
						if(value == null || value.trim().equals(""))
							buff.append("");
						else
							buff.append(Util.changeSpecialString(value));
						buff.append("</").append(fieldname).append(">\r\n");
					}
					buff.append("</").append(obj.getClass().getName()).append(">\r\n");
				}
			}
		} catch (Throwable t) {
			log.error("BaseEntity ListToXML is error:", t);
			buff = null;
		}
		return buff.toString();
	}
	
	/**
	 * 设置瑞金系统配置
	 */
	public static void SetRuiJingConfigParam() {
		Object obj = null;
		try {
			if(Util.strIsNullOrEmpty(RuiJingConfigParam.getHz_service_url())) {
				obj = SpringFactory.getInstance().getBean("ruijing");
			}
		} catch (Throwable t) {
			log.error("BaseEntity SetRuiJingConfigParam is error:", t);
		} 	
	}
	
	public static void SetRuiJingConfigParam2() {
		Object obj = null;
		try {
			if(Util.strIsNullOrEmpty(RuiJingConfigParam.getHz_service_url2())) {
				obj = SpringFactory.getInstance().getBean("ruijing");
			}
		} catch (Throwable t) {
			log.error("BaseEntity SetRuiJingConfigParam is error:", t);
		} 	
	}

	/**
	 * 设置学透通的配置
	 */
	public static void SetXueTouTongConfigParam() {
		Object obj = null;
		try {
			if(Util.strIsNullOrEmpty(XueTouTongConfigParam.getPat_emr_url())) {
				obj = SpringFactory.getInstance().getBean("XueTouTong");
			}
		} catch (Throwable t) {
			log.error("BaseEntity SetXueTouTongConfigParam is error:", t);
		} 
	}
	
	/**
	 * 设置学透通的配置
	 */
	public static void SetCnmiaConfigParam() {
		Object obj = null;
		try {
			if(Util.strIsNullOrEmpty(CnmiaConfigParam.getAutologin_url())) {
				obj = SpringFactory.getInstance().getBean("Cnmia");
			}
		} catch (Throwable t) {
			log.error("BaseEntity SetXueTouTongConfigParam is error:", t);
		} 
	}
}

