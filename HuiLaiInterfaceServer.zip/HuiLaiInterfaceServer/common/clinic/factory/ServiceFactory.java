package clinic.factory;

/*
 * Created on 2006-5-16
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import org.springframework.context.ApplicationContext;
import clinic.service.IJsonService;
import clinic.utils.ftp.FTPConfig;
import clinic.utils.ftp.FtpUtil;
/**
 * @author xuanzi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ServiceFactory {
	
	private static ServiceFactory inst = new ServiceFactory();

	transient static ApplicationContext ctx = SpringFactory.getContext();

	public static ServiceFactory getInstance() {
		return inst;
	}
	
	public IJsonService getSogoService() {
		return (IJsonService)ctx.getBean("SogoIntegerOBJ");
	}
	
	public FTPConfig getFTPConfig() {
		return (FTPConfig)ctx.getBean("FTPConfig");
	}
	
	public FtpUtil getFTPUtil() {
		return (FtpUtil)ctx.getBean("FTPUtil");
	}

}