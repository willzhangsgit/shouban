package clinic.factory;

import DAO.*;
import DAO.Impl.*;
import Domain.*;

public class DomainDAOFactory {
	public static CnmiaDomain getCnmianDomain() {
		return new CnmiaDomain();
	}
	
	public static ICnmiaDAO getCnmiaDAO (){
		return new CnmiaDAOImpl();
	}
	
	public static RuiJingDomain getRuiJingDomain() {
		return new RuiJingDomain();
	}
	
	public static IRuiJingDAO getRuiJingDAO (){
		return new RuiJingDAOImpl();
	}
	
	public static IXueTouTongDAO getXueTouTongDAO() {
		return new XueTouTongDAOImpl();
	}
	
	public static HuiLaiDomain getHuiLaiDomain() {
		return new HuiLaiDomain();
	}
	
	public static IHuiLaiDAO getHuiLaiDAO() {
		return new HuiLaiDAOImpl();
	}
}
