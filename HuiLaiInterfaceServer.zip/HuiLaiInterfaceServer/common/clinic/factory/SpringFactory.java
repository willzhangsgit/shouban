package clinic.factory;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

/**
 * @author cbx
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SpringFactory {

	static SpringFactory inst = new SpringFactory();

	static ApplicationContext ctx;

	static String[] xmls = { "services.xml", "db.xml" ,"domain.xml" , "dao.xml" , "ftpconfig.xml"};

	public static SpringFactory getInstance() {
		getContext();
		return inst;
	}

	static ApplicationContext getContext() {
		if (ctx == null)
			ctx = new ClassPathXmlApplicationContext(xmls);
		return ctx;
	}
	
	public 	DataSourceTransactionManager getTransactionManager()
	{
		DataSourceTransactionManager dtm=(DataSourceTransactionManager)ctx.getBean("transactionManager");
		return dtm;
	}
	
	public Object getBean(String bean) {
		return ctx.getBean(bean);
	}
	
	public DataSource getDataSource() {
		return (DataSource)ctx.getBean("MySQL");
	}
}

