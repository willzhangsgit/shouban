package clinic.entity.XueTouTong;

public class XueTouTongConfigParam {
	/**
	 * 学透通患者病历的URL
	 */
	static String pat_emr_url;		
	/**
	 * 学透通调用患者病历默认的token
	 */
	static String cookie_token;		
	/**
	 * 学透通自动登录的URL
	 */
	static String sogo_xtt_autologin_url;
	/**
	 * 学透通患者病历的URL
	 * @return
	 */
	public static String getPat_emr_url() {
		return pat_emr_url;
	}
	/**
	 * 学透通患者病历的URL
	 * @param pat_emr_url
	 */
	public void setPat_emr_url(String pat_emr_url) {
		XueTouTongConfigParam.pat_emr_url = pat_emr_url;
	}
	/**
	 * 学透通调用患者病历默认的token
	 * @return
	 */
	public static String getCookie_token() {
		return cookie_token;
	}
	/**
	 * 学透通调用患者病历默认的token
	 * @param cookie_token
	 */
	public void setCookie_token(String cookie_token) {
		XueTouTongConfigParam.cookie_token = cookie_token;
	}
	/**
	 * 学透通自动登录的URL
	 * @return
	 */
	public static String getSogo_xtt_autologin_url() {
		return sogo_xtt_autologin_url;
	}
	/**
	 * 学透通自动登录的URL
	 * @param sogo_xtt_autologin_url
	 */
	public void setSogo_xtt_autologin_url(String sogo_xtt_autologin_url) {
		XueTouTongConfigParam.sogo_xtt_autologin_url = sogo_xtt_autologin_url;
	}
}
