package clinic.entity.Cnmia;

public class CnmiaMeetingInfo {
	/**
	 * 主键
	 */
	private int id;
	/**
	 * 非公会议室号码
	 */
	private String serial;
	/**
	 * 会议参与方
	 */
	private String partners;
	/**
	 * 患者姓名
	 */
	private String patient;
	/**
	 * 患者性别
	 */
	private String gender;
	/**
	 * 患者年龄
	 */
	private String age;
	/**
	 * 部门编号
	 */
	private String department;
	/**
	 * 诊断
	 */
	private String diagnosis;
	/**
	 * 主诉
	 */
	private String chiefcomplaint;
	/**
	 * 现病史
	 */
	private String illcase;
	/**
	 * 既往史
	 */
	private String illhistory;
	/**
	 * 家族史
	 */
	private String familycase;
	/**
	 * 体格检查
	 */
	private String physical;
	/**
	 * 辅助检查
	 */
	private String accessory;
	/**
	 * 处理意见
	 */
	private String treatment;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getPartners() {
		return partners;
	}
	public void setPartners(String partners) {
		this.partners = partners;
	}
	public String getPatient() {
		return patient;
	}
	public void setPatient(String patient) {
		this.patient = patient;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	public String getChiefcomplaint() {
		return chiefcomplaint;
	}
	public void setChiefcomplaint(String chiefcomplaint) {
		this.chiefcomplaint = chiefcomplaint;
	}
	public String getIllcase() {
		return illcase;
	}
	public void setIllcase(String illcase) {
		this.illcase = illcase;
	}
	public String getIllhistory() {
		return illhistory;
	}
	public void setIllhistory(String illhistory) {
		this.illhistory = illhistory;
	}
	public String getFamilycase() {
		return familycase;
	}
	public void setFamilycase(String familycase) {
		this.familycase = familycase;
	}
	public String getPhysical() {
		return physical;
	}
	public void setPhysical(String physical) {
		this.physical = physical;
	}
	public String getAccessory() {
		return accessory;
	}
	public void setAccessory(String accessory) {
		this.accessory = accessory;
	}
	public String getTreatment() {
		return treatment;
	}
	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}
}
