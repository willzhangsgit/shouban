package clinic.entity.Cnmia;

import java.util.Date;

public class CnmiaUserInfo {

	/**
	 * 主键KEY
	 */
	private int id;	
	/**
	 * 用户名
	 */
	private String userid;
	/**
	 * 用户密码
	 */
	private String pw;
	/**
	 * 项目KEY
	 */
	private String projectkey;
	/**
	 * SecretKey
	 */
	private String scrcetkey;
	/**
	 * 最后登录时间
	 */
	private Date lastlogintime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getProjectkey() {
		return projectkey;
	}
	public void setProjectkey(String projectkey) {
		this.projectkey = projectkey;
	}
	public String getScrcetkey() {
		return scrcetkey;
	}
	public void setScrcetkey(String scrcetkey) {
		this.scrcetkey = scrcetkey;
	}
	public Date getLastlogintime() {
		return lastlogintime;
	}
	public void setLastlogintime(Date lastlogintime) {
		this.lastlogintime = lastlogintime;
	}
}
