package clinic.entity.Cnmia;

public class CnmiaConfigParam {
	/**
	 * 非公医疗自动登录的URL
	 */
	static String autologin_url;	
	/**
	 * 非公医疗发起端（医生端）自动登录的URL
	 */
	static String initiator_autologin_url;
	/**
	 * 非公医疗受邀端（专家端））自动登录的URL
	 */
	static String receiver_autologin_url;
	public static String getAutologin_url() {
		return autologin_url;
	}
	public void setAutologin_url(String autologin_url) {
		CnmiaConfigParam.autologin_url = autologin_url;
	}
	public static String getInitiator_autologin_url() {
		return initiator_autologin_url;
	}
	public void setInitiator_autologin_url(String initiator_autologin_url) {
		CnmiaConfigParam.initiator_autologin_url = initiator_autologin_url;
	}
	public static String getReceiver_autologin_url() {
		return receiver_autologin_url;
	}
	public void setReceiver_autologin_url(String receiver_autologin_url) {
		CnmiaConfigParam.receiver_autologin_url = receiver_autologin_url;
	}
	
}
