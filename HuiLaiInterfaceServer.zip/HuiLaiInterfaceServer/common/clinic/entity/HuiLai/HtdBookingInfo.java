package clinic.entity.HuiLai;

public class HtdBookingInfo {
	/**
	 * 预约编号
	 */
	private String yyid;
	/**
	 * 申请提交日期
	 */
	private String sqtjsj;
	/**
	 * 期望就诊日期
	 */
	private String yyjzsj;
	/**
	 * 预约状态 "0":"已注册","1":"预诊确认","2":"门诊提交","3":"门诊确认","4":"已通知","5":"撤销","6":"爽约","9":"预诊提交"
	 */
	private int yyzt;
	/**
	 * 就诊状态 "1":"未就诊","2":"就诊中","3":"已就诊
	 */
	private int jzzt;
	/**
	 * 患者唯一编号
	 */
	private String pid;
	/**
	 * 有效性  1:有效 0:无效
	 */
	private int status;
	/**
	 * 发起医院编号
	 */
	private String fqhospno;
	/**
	 * 发起医院名称
	 */
	private String fqhospname;
	/**
	 * 发起科室编号
	 */
	private String fqks;
	/**
	 * 发起科室名称
	 */
	private String fqksmc;
	/**
	 * 发起医生编号
	 */
	private String fqysid;
	/**
	 * 发起医生姓名
	 */
	private String fqysxm;
	/**
	 * 患者姓名
	 */
	private String xm;
	/**
	 * 患者身份证
	 */
	private String sfzh;
	/**
	 * 瑞金大科室编号
	 */
	private String rjksbh;
	/**
	 * 瑞金小科室编号
	 */
	private String rjchildksbh;
	/**
	 * 瑞金大科室名称
	 */
	private String rjksmc;
	/**
	 * 瑞金小科室名称
	 */
	private String rjchildksmc;
	/**
	 * 瑞金会诊ID
	 */
	private String rjhzid;
	
	public String getYyid() {
		return yyid;
	}
	public void setYyid(String yyid) {
		this.yyid = yyid;
	}
	public String getSqtjsj() {
		return sqtjsj;
	}
	public void setSqtjsj(String sqtjsj) {
		this.sqtjsj = sqtjsj;
	}
	public String getYyjzsj() {
		return yyjzsj;
	}
	public void setYyjzsj(String yyjzsj) {
		this.yyjzsj = yyjzsj;
	}
	public int getYyzt() {
		return yyzt;
	}
	public void setYyzt(int yyzt) {
		this.yyzt = yyzt;
	}
	public int getJzzt() {
		return jzzt;
	}
	public void setJzzt(int jzzt) {
		this.jzzt = jzzt;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getFqhospno() {
		return fqhospno;
	}
	public void setFqhospno(String fqhospno) {
		this.fqhospno = fqhospno;
	}
	public String getFqks() {
		return fqks;
	}
	public void setFqks(String fqks) {
		this.fqks = fqks;
	}
	public String getFqysid() {
		return fqysid;
	}
	public void setFqysid(String fqysid) {
		this.fqysid = fqysid;
	}
	public String getFqysxm() {
		return fqysxm;
	}
	public void setFqysxm(String fqysxm) {
		this.fqysxm = fqysxm;
	}
	public String getXm() {
		return xm;
	}
	public void setXm(String xm) {
		this.xm = xm;
	}
	public String getSfzh() {
		return sfzh;
	}
	public void setSfzh(String sfzh) {
		this.sfzh = sfzh;
	}
	/**
	 * @return the fqhospname
	 */
	public String getFqhospname() {
		return fqhospname;
	}
	/**
	 * @param fqhospname the fqhospname to set
	 */
	public void setFqhospname(String fqhospname) {
		this.fqhospname = fqhospname;
	}
	/**
	 * @return the fqksmc
	 */
	public String getFqksmc() {
		return fqksmc;
	}
	/**
	 * @param fqksmc the fqksmc to set
	 */
	public void setFqksmc(String fqksmc) {
		this.fqksmc = fqksmc;
	}
	/**
	 * @return the rjksbh
	 */
	public String getRjksbh() {
		return rjksbh;
	}
	/**
	 * @param rjksbh the rjksbh to set
	 */
	public void setRjksbh(String rjksbh) {
		this.rjksbh = rjksbh;
	}
	/**
	 * @return the rjchildksbh
	 */
	public String getRjchildksbh() {
		return rjchildksbh;
	}
	/**
	 * @param rjchildksbh the rjchildksbh to set
	 */
	public void setRjchildksbh(String rjchildksbh) {
		this.rjchildksbh = rjchildksbh;
	}
	/**
	 * @return the rjksmc
	 */
	public String getRjksmc() {
		return rjksmc;
	}
	/**
	 * @param rjksmc the rjksmc to set
	 */
	public void setRjksmc(String rjksmc) {
		this.rjksmc = rjksmc;
	}
	/**
	 * @return the rjchildksmc
	 */
	public String getRjchildksmc() {
		return rjchildksmc;
	}
	/**
	 * @param rjchildksmc the rjchildksmc to set
	 */
	public void setRjchildksmc(String rjchildksmc) {
		this.rjchildksmc = rjchildksmc;
	}
	/**
	 * @return the rjhzid
	 */
	public String getRjhzid() {
		return rjhzid;
	}
	/**
	 * @param rjhzid the rjhzid to set
	 */
	public void setRjhzid(String rjhzid) {
		this.rjhzid = rjhzid;
	}
}
