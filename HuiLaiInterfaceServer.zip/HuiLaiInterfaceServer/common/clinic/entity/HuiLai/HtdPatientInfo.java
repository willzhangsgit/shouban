package clinic.entity.HuiLai;

public class HtdPatientInfo {
	private String pid;
	private String xm;
	private String xb;
	private String sfzh;
	private String csrq;
	private String sjh;
	private String dz;
	public HtdPatientInfo() {
		pid = "";
		xm = "";
		xb = "";
		sfzh = "";
		csrq = "";
		sjh = "";
		dz = "";
	}
	/**
	 * 病人唯一编号GUID
	 * @return
	 */
	public String getPid() {
		return pid;
	}
	/**
	 * 病人唯一编号GUID
	 * @param pid
	 */
	public void setPid(String pid) {
		this.pid = pid;
	}
	/**
	 * 姓名
	 * @return
	 */
	public String getXm() {
		return xm;
	}
	/**
	 * 姓名
	 * @param xm
	 */
	public void setXm(String xm) {
		this.xm = xm;
	}
	/**
	 * 性别
	 * @return
	 */
	public String getXb() {
		return xb;
	}
	/**
	 * 性别
	 * @param xb
	 */
	public void setXb(String xb) {
		this.xb = xb;
	}
	/**
	 * 身份证
	 * @return
	 */
	public String getSfzh() {
		return sfzh;
	}
	/**
	 * 身份证
	 * @param sfzh
	 */
	public void setSfzh(String sfzh) {
		this.sfzh = sfzh;
	}
	/**
	 * 生日
	 * @return
	 */
	public String getCsrq() {
		return csrq;
	}
	/**
	 * 生日
	 * @param csrq
	 */
	public void setCsrq(String csrq) {
		this.csrq = csrq;
	}
	/**
	 * 手机号
	 * @return
	 */
	public String getSjh() {
		return sjh;
	}
	/**
	 * 手机号
	 * @param sjh
	 */
	public void setSjh(String sjh) {
		this.sjh = sjh;
	}
	/**
	 * 地址
	 * @return
	 */
	public String getDz() {
		return dz;
	}
	/**
	 * 地址
	 * @param dz
	 */
	public void setDz(String dz) {
		this.dz = dz;
	}
	
}
