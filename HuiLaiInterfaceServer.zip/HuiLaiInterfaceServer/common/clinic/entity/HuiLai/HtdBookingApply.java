package clinic.entity.HuiLai;

import clinic.utils.Util;

public class HtdBookingApply {

	private String yyid;
	private String lczd;
	private String zs;
	private String xbs;
	private String jws;
	private String jzs;
	private String tgjc;
	private String fzjc;
	private String zlgc;
	private String hzmd;
	
	public HtdBookingApply()
	{
		yyid = "无";
		lczd = "无";
		zs = "无";
		xbs = "无";
		jws = "无";
		jzs = "无";
		tgjc = "无";
		fzjc = "无";
		zlgc = "无";
		hzmd = "无";
	}
	
	/**
	 * @return the 预约编号
	 */
	public String getYyid() {
		return yyid;
	}
	/**
	 * @param yyid the 预约编号
	 */
	public void setYyid(String yyid) {
		this.yyid = yyid;
	}
	/**
	 * @return the 临床诊断
	 * @throws Exception 
	 */
	public String getLczd() throws Exception {
		if(Util.strIsNullOrEmpty(lczd))
			lczd = "无";
		return lczd;
	}
	/**
	 * @param lczd the 临床诊断 to set
	 */
	public void setLczd(String lczd) {
		this.lczd = lczd;
	}
	/**
	 * @return the 主诉
	 * @throws Exception 
	 */
	public String getZs() throws Exception {
		if(Util.strIsNullOrEmpty(zs))
			zs = "无";
		return zs;
	}
	/**
	 * @param zs the 主诉 to set
	 */
	public void setZs(String zs) {
		this.zs = zs;
	}
	/**
	 * @return the 现病史
	 * @throws Exception 
	 */
	public String getXbs() throws Exception {
		if(Util.strIsNullOrEmpty(xbs))
			xbs = "无";
		return xbs;
	}
	/**
	 * @param xbs the 现病史 to set
	 */
	public void setXbs(String xbs) {
		this.xbs = xbs;
	}
	/**
	 * @return the 既往史
	 * @throws Exception 
	 */
	public String getJws() throws Exception {
		if(Util.strIsNullOrEmpty(jws))
			jws = "无";
		return jws;
	}
	/**
	 * @param jws the 既往史 to set
	 */
	public void setJws(String jws) {
		this.jws = jws;
	}
	/**
	 * @return the 家族史
	 * @throws Exception 
	 */
	public String getJzs() throws Exception {
		if(Util.strIsNullOrEmpty(jzs))
			jzs = "无";
		return jzs;
	}
	/**
	 * @param jzs the 家族史 to set
	 */
	public void setJzs(String jzs) {
		this.jzs = jzs;
	}
	/**
	 * @return the 体格检查
	 * @throws Exception 
	 */
	public String getTgjc() throws Exception {
		if(Util.strIsNullOrEmpty(tgjc))
			tgjc = "无";
		return tgjc;
	}
	/**
	 * @param tgjc the 体格检查 to set
	 */
	public void setTgjc(String tgjc) {
		this.tgjc = tgjc;
	}
	/**
	 * @return the 辅助检查
	 * @throws Exception 
	 */
	public String getFzjc() throws Exception {
		if(Util.strIsNullOrEmpty(fzjc))
			fzjc = "无";
		return fzjc;
	}
	/**
	 * @param fzjc the 辅助检查 to set
	 */
	public void setFzjc(String fzjc) {
		this.fzjc = fzjc;
	}
	/**
	 * @return the 治疗过程
	 * @throws Exception 
	 */
	public String getZlgc() throws Exception {
		if(Util.strIsNullOrEmpty(zlgc))
			zlgc = "无";
		return zlgc;
	}
	/**
	 * @param zlgc the 治疗过程 to set
	 */
	public void setZlgc(String zlgc) {
		this.zlgc = zlgc;
	}
	/**
	 * @return the 会诊目的
	 * @throws Exception 
	 */
	public String getHzmd() throws Exception {
		if(Util.strIsNullOrEmpty(hzmd))
			hzmd = "无";
		return hzmd;
	}
	/**
	 * @param hzmd the 会诊目的 to set
	 */
	public void setHzmd(String hzmd) {
		this.hzmd = hzmd;
	}

}
