package clinic.entity.Magnolia;

public class ApplyReq {
	
	private String consultationType;
	private String thirdSourceUUID;
	private String ThirdSourceId;
	private String thirdApplyId;
	private String thirdHospitalName;
	private String thirdHospitalOrganizationName;
	private String thirdHospitalSubOrganizationName;
	private String serialNumber;
	private String consultationWay;
	private String serverInstiuttionUUID;
	private String serverInstiuttionId;
	private String appointTime;
	private String dayRangeType;
	private String patientName;
	private String patientIdTypeName;
	private String patientIdNumber;
	private String patientAge;
	private String patientSex;
	private String currentMedicalHistory;
	private String pastHistory;
	private String allergicHistory;
	private String checkUp;
	private String accessoryExam;
	private String tentativeDiagnosis;
	private String treatmentProcess;
	private String mainDoctor;
	private String cosultationPurposeDescription;
	private String cosultationPurposeProfile;
	private String serverDepartmentIds;
	private String attachStr;
	
	public String getConsultationType() {
		return consultationType;
	}
	public void setConsultationType(String consultationType) {
		this.consultationType = consultationType;
	}
	public String getThirdSourceId() {
		return ThirdSourceId;
	}
	public void setThirdSourceId(String thirdSourceId) {
		ThirdSourceId = thirdSourceId;
	}
	public String getThirdApplyId() {
		return thirdApplyId;
	}
	public void setThirdApplyId(String thirdApplyId) {
		this.thirdApplyId = thirdApplyId;
	}
	public String getThirdHospitalName() {
		return thirdHospitalName;
	}
	public void setThirdHospitalName(String thirdHospitalName) {
		this.thirdHospitalName = thirdHospitalName;
	}
	public String getThirdHospitalOrganizationName() {
		return thirdHospitalOrganizationName;
	}
	public void setThirdHospitalOrganizationName(String thirdHospitalOrganizationName) {
		this.thirdHospitalOrganizationName = thirdHospitalOrganizationName;
	}
	public String getThirdHospitalSubOrganizationName() {
		return thirdHospitalSubOrganizationName;
	}
	public void setThirdHospitalSubOrganizationName(String thirdHospitalSubOrganizationName) {
		this.thirdHospitalSubOrganizationName = thirdHospitalSubOrganizationName;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getConsultationWay() {
		return consultationWay;
	}
	public void setConsultationWay(String consultationWay) {
		this.consultationWay = consultationWay;
	}
	public String getServerInstiuttionId() {
		return serverInstiuttionId;
	}
	public void setServerInstiuttionId(String serverInstiuttionId) {
		this.serverInstiuttionId = serverInstiuttionId;
	}
	public String getAppointTime() {
		return appointTime;
	}
	public void setAppointTime(String appointTime) {
		this.appointTime = appointTime;
	}
	public String getDayRangeType() {
		return dayRangeType;
	}
	public void setDayRangeType(String dayRangeType) {
		this.dayRangeType = dayRangeType;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientIdTypeName() {
		return patientIdTypeName;
	}
	public void setPatientIdTypeName(String patientIdTypeName) {
		this.patientIdTypeName = patientIdTypeName;
	}
	public String getPatientIdNumber() {
		return patientIdNumber;
	}
	public void setPatientIdNumber(String patientIdNumber) {
		this.patientIdNumber = patientIdNumber;
	}
	public String getPatientAge() {
		return patientAge;
	}
	public void setPatientAge(String patientAge) {
		this.patientAge = patientAge;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	
	public String getCurrentMedicalHistory() {
		return currentMedicalHistory;
	}
	public void setCurrentMedicalHistory(String currentMedicalHistory) {
		this.currentMedicalHistory = currentMedicalHistory;
	}
	public String getPastHistory() {
		return pastHistory;
	}
	public void setPastHistory(String pastHistory) {
		this.pastHistory = pastHistory;
	}
	public String getAllergicHistory() {
		return allergicHistory;
	}
	public void setAllergicHistory(String allergicHistory) {
		this.allergicHistory = allergicHistory;
	}
	public String getCheckUp() {
		return checkUp;
	}
	public void setCheckUp(String checkUp) {
		this.checkUp = checkUp;
	}
	public String getAccessoryExam() {
		return accessoryExam;
	}
	public void setAccessoryExam(String accessoryExam) {
		this.accessoryExam = accessoryExam;
	}
	public String getTentativeDiagnosis() {
		return tentativeDiagnosis;
	}
	public void setTentativeDiagnosis(String tentativeDiagnosis) {
		this.tentativeDiagnosis = tentativeDiagnosis;
	}
	public String getTreatmentProcess() {
		return treatmentProcess;
	}
	public void setTreatmentProcess(String treatmentProcess) {
		this.treatmentProcess = treatmentProcess;
	}
	public String getMainDoctor() {
		return mainDoctor;
	}
	public void setMainDoctor(String mainDoctor) {
		this.mainDoctor = mainDoctor;
	}
	public String getCosultationPurposeDescription() {
		return cosultationPurposeDescription;
	}
	public void setCosultationPurposeDescription(String cosultationPurposeDescription) {
		this.cosultationPurposeDescription = cosultationPurposeDescription;
	}
	public String getCosultationPurposeProfile() {
		return cosultationPurposeProfile;
	}
	public void setCosultationPurposeProfile(String cosultationPurposeProfile) {
		this.cosultationPurposeProfile = cosultationPurposeProfile;
	}
	public String getAttachStr() {
		return attachStr;
	}
	public void setAttachStr(String attachStr) {
		this.attachStr = attachStr;
	}
	
	public String getServerDepartmentIds() {
		return serverDepartmentIds;
	}
	public void setServerDepartmentIds(String serverDepartmentIds) {
		this.serverDepartmentIds = serverDepartmentIds;
	}
	
	public String getThirdSourceUUID() {
		return thirdSourceUUID;
	}
	public void setThirdSourceUUID(String thirdSourceUUID) {
		this.thirdSourceUUID = thirdSourceUUID;
	}
	
	public String getServerInstiuttionUUID() {
		return serverInstiuttionUUID;
	}
	public void setServerInstiuttionUUID(String serverInstiuttionUUID) {
		this.serverInstiuttionUUID = serverInstiuttionUUID;
	}
	
	public ApplyReq() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "ApplyReq [consultationType=" + consultationType + ", thirdSourceUUID=" + thirdSourceUUID
				+ ", ThirdSourceId=" + ThirdSourceId + ", thirdApplyId=" + thirdApplyId + ", thirdHospitalName="
				+ thirdHospitalName + ", thirdHospitalOrganizationName=" + thirdHospitalOrganizationName
				+ ", thirdHospitalSubOrganizationName=" + thirdHospitalSubOrganizationName + ", serialNumber="
				+ serialNumber + ", consultationWay=" + consultationWay + ", serverInstiuttionUUID="
				+ serverInstiuttionUUID + ", serverInstiuttionId=" + serverInstiuttionId + ", appointTime="
				+ appointTime + ", dayRangeType=" + dayRangeType + ", patientName=" + patientName
				+ ", patientIdTypeName=" + patientIdTypeName + ", patientIdNumber=" + patientIdNumber + ", patientAge="
				+ patientAge + ", patientSex=" + patientSex + ", currentMedicalHistory=" + currentMedicalHistory
				+ ", pastHistory=" + pastHistory + ", allergicHistory=" + allergicHistory + ", checkUp=" + checkUp
				+ ", accessoryExam=" + accessoryExam + ", tentativeDiagnosis=" + tentativeDiagnosis
				+ ", treatmentProcess=" + treatmentProcess + ", mainDoctor=" + mainDoctor
				+ ", cosultationPurposeDescription=" + cosultationPurposeDescription + ", cosultationPurposeProfile="
				+ cosultationPurposeProfile + ", serverDepartmentIds=" + serverDepartmentIds + ", attachStr="
				+ attachStr + "]";
	}
	
	
}
