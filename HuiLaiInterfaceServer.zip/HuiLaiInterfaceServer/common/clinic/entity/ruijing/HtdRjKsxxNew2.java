package clinic.entity.ruijing;

import java.sql.Date;

public class HtdRjKsxxNew2 {

	private String rjKsbh;
	
	private String rjKsid;

	private String rjKsmc;

	private String HOSPITAL_ID;

	private String PARENT_ID;

	private String DESCRIPTION;

	private String ourDeptId;
	
	private Date optime;

	public String getRjKsbh() {
		return rjKsbh;
	}

	public void setRjKsbh(String rjKsbh) {
		this.rjKsbh = rjKsbh;
	}

	public String getRjKsid() {
		return rjKsid;
	}

	public void setRjKsid(String rjKsid) {
		this.rjKsid = rjKsid;
	}

	public String getRjKsmc() {
		return rjKsmc;
	}

	public void setRjKsmc(String rjKsmc) {
		this.rjKsmc = rjKsmc;
	}

	public String getHOSPITAL_ID() {
		return HOSPITAL_ID;
	}

	public void setHOSPITAL_ID(String hOSPITAL_ID) {
		HOSPITAL_ID = hOSPITAL_ID;
	}

	public String getPARENT_ID() {
		return PARENT_ID;
	}

	public void setPARENT_ID(String pARENT_ID) {
		PARENT_ID = pARENT_ID;
	}

	public String getDESCRIPTION() {
		return DESCRIPTION;
	}

	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}

	public String getOurDeptId() {
		return ourDeptId;
	}

	public void setOurDeptId(String ourDeptId) {
		this.ourDeptId = ourDeptId;
	}

	public Date getOptime() {
		return optime;
	}

	public void setOptime(Date optime) {
		this.optime = optime;
	}
	
}
