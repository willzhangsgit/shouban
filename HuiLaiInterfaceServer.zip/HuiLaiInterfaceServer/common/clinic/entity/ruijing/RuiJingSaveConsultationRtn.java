package clinic.entity.ruijing;

public class RuiJingSaveConsultationRtn {
	public RuiJingSaveConsultationRtn() {
		this.rjhzid = "";
		this.code = "";
		this.msg = "";
		this.output = "";
	}
	
	/**
	 * 返回的JSON
	 */
	private String output;
	/**
	 * 瑞金平台的会诊号
	 */
	private String rjhzid;
	/**
	 * 返回CODE
	 */
	private String code;
	/**
	 * 返回的提示信息
	 */
	private String msg;
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getRjhzid() {
		return rjhzid;
	}
	public void setRjhzid(String rjhzid) {
		this.rjhzid = rjhzid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
