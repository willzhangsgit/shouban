package clinic.entity.ruijing;

public class RuiJingConfigParam {
	static String hz_service_url;	//瑞金平台接口URL
	static String hz_service_url2;	//瑞金平台接口URL
	static int commit_interval;	//上传间隔时间
	static int yyzt;			//需要上传的预约状态
	static int jzzt;			//需要上传的就诊状态
	static String bdrjyybh;		//本地瑞金医院编号
	//static String bdszkksbh;	//本地生殖科科室编号
	static String requestid;	//我们在瑞金平台的申请ID
	//static String reqhospitalid;	//我们在瑞金平台的医院ID 
	//static String reqhospital;		//我们在瑞金平台的医院名称
	//static String reqdepartmentid;	//我们在瑞金平台的科室ID
	//static String reqdepartment;	//我们在瑞金平台的科室名称
	static String ptrjyybh;		//平台瑞金医院编号
	//static String ptrjszkbh;	//平台瑞金生殖科科室编号

	public static String getHz_service_url() {
		return hz_service_url;
	}

	public void setHz_service_url(String hz_service_url) {
		RuiJingConfigParam.hz_service_url = hz_service_url;
	}

	public static int getCommit_interval() {
		return commit_interval;
	}

	public void setCommit_interval(int commit_interval) {
		RuiJingConfigParam.commit_interval = commit_interval;
	}

	public static int getYyzt() {
		return yyzt;
	}

	public void setYyzt(int yyzt) {
		RuiJingConfigParam.yyzt = yyzt;
	}

	public static int getJzzt() {
		return jzzt;
	}

	public void setJzzt(int jzzt) {
		RuiJingConfigParam.jzzt = jzzt;
	}

	public static String getBdrjyybh() {
		return bdrjyybh;
	}

	public void setBdrjyybh(String bdrjyybh) {
		RuiJingConfigParam.bdrjyybh = bdrjyybh;
	}

	public static String getPtrjyybh() {
		return ptrjyybh;
	}

	public void setPtrjyybh(String ptrjyybh) {
		RuiJingConfigParam.ptrjyybh = ptrjyybh;
	}

	public static String getRequestid() {
		return requestid;
	}

	public void setRequestid(String requestid) {
		RuiJingConfigParam.requestid = requestid;
	}

	public static String getHz_service_url2() {
		return hz_service_url2;
	}

	public void setHz_service_url2(String hz_service_url2) {
		RuiJingConfigParam.hz_service_url2 = hz_service_url2;
	}
	
}
