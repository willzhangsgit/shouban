/**
 * Created with JetBrains WebStorm.
 * User: HWZ
 * Date: 17-10-1
 * Time: 上午11:04
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function(){
	
	var isLogin = false;    //用户是否已经登录 false:没有登录   true:已经登录
	var showVideo = true;   //显示视频  true:显示视频  false:不显示视频
	var callId;        //呼叫唯一编号
	var isMuted = false;    //静音标志位  false:没有静音  true:静音状态
	var isHeld = false;     //保持呼叫标志位
	var curConferenceId;    //会议室号
	
	setDiv();
	initKandy();
	
	function setDiv()
    {
        var w = document.body.clientWidth - 420;
        var h = w / 1.77;
        document.getElementById("remoteVedio").style.width = w + "px";
        document.getElementById("remoteVedio").style.height = h + "px";
        
        document.getElementById("dLeft").style.height = h + 20 + "px";
        document.getElementById("dPat").style.height = h + 20 - 135 + "px";
        
        w = w / 5;
        h = w / 1.33;
        document.getElementById("localVedio").style.width = w + "px";
        document.getElementById("localVedio").style.height = h + "px";
        
    }
	
	/**
	 * 获取request参数
	 * @param name
	 * @returns
	 */
	function getQueryString(name) { 
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
		var r = window.location.search.substr(1).match(reg); 
		if (r != null) return unescape(r[2]); return null; 
	} 
	
	/**
	 * 显示信息函数
	 * @param message
	 */
	function log(message , divColor)
	{
	    //document.getElementById("messages").innerHTML = document.getElementById("messages").innerHTML + "<br>" + "<div style='background-color: " + divColor + "'>" + message + "</div>";
	}
	
	/**
	 * 初始化控件
	 */
	function initKandy()
	{
		curConferenceId = $("#room").text();
	    // Configure Kandy for the features we want to use.
	    kandy.setup(
	        {
	            remoteVideoContainer: $("#remoteVedio"),
	            localVideoContainer: $("#localVedio"),
	            loglevel:"debug",
	            listeners: {
	                callinitiated: onCallInitiated,             //调用makeCall呼叫，主叫端呼叫成功
	                callinitiatefailed: onCallInitiateFailed,   //调用makeCall呼叫，主叫端呼叫失败
	                callincoming: onCallIncoming,               //调用makeCall呼叫，主叫端呼叫成功，被叫端执行触发
	                callanswered: onCallAnswered,               //调用answerCall应答，被叫端触发
	                callanswerfailed: onCallAnswerFailed,       //调用answerCall应答，被叫端触发
	                callrejected: onCallRejected,               //调用rejectCall拒接，被叫端触发
	                callrejectfailed: onCallRejectFailed,       //调用rejectCall拒接，被叫端触发
	                callhold: onCallHold,
	                callunhold: onCallUnHold,
	                callended: onCallEnded,
	                callendfailed: onCallEndFailed,
	                callestablished: onCallEstablished,         //呼叫建立，主端和被端都触发
	                callstatechanged: onCallStateChanged
	            },
	            kandyApiUrl: 'https://api.kandycn.com/v1.3'
	        });
	    kandy.internal.initLogger();
	    log("初始化成功" , "blue");
	    userLogin();
	}

	/**
	 * Makecall 是一个异步函数,当他成功完时callinitiated 事件将被触发，
	 * @param call
	 * @param callee
	 */
	function onCallInitiated(call, callee)
	 {
//	     log("Call initiated with " + callee + ". Ringing..." , "blue");
//	     // Store the call id, so the caller has access to it.
//	     callId = call.getId();
//	     // Handle UI changes. A call is in progress.
//	     document.getElementById("make-call").disabled = true;
//	     document.getElementById("end-call").disabled = false;
	 }

	function onCallInitiateFailed()
	{
//	    log("呼叫失败","red");
	}

	/**
	 * 收到来电
	 * 当有一个来电时,callincoming 事件将被触发,回调函数onCallIncoming将被调用
	 * 这个回函数里面,call参数包含了这个来电的相关信息
	 * @param call
	 */
	function onCallIncoming(call)
	{
//	    log("Incoming call from " + call.callerNumber);
//	    // Store the call id, so the callee has access to it.
//	    callId = call.getId();
//	    // Handle UI changes. A call is incoming.
//	    document.getElementById("accept-call").disabled = false;
//	    document.getElementById("decline-call").disabled = false;
	}

	function onCallAnswered()
	{

	}

	function onCallAnswerFailed()
	{

	}

	function onCallRejected()
	{

	}

	function onCallRejectFailed()
	{

	}

	function onCallHold()
	{

	}

	function onCallUnHold()
	{

	}

	/**
	 * 拒绝呼叫
	 * 如果被叫方拒绝接听呼叫,callended事件将被触发,回调函数onCallEnded将被调用
	 */
	function onCallEnded(call)
	{
//	    log("Call ended." , "blue");
//	    // Handle UI changes. No current call.
//	    document.getElementById("make-call").disabled = false;
//	    document.getElementById("mute-call").disabled = true;
//	    document.getElementById("hold-call").disabled = true;
//	    document.getElementById("end-call").disabled = true;
//	    // Call no longer active, reset mute and hold statuses.
//	    isMuted = false;
//	    isHeld = false;
	}

	function onCallEndFailed()
	{

	}

	/**
	 * 呼叫建立
	 * 如果被叫接受来电,在主侧callestablished事件将被触发,onCallEstablished回调让用户知道呼叫在进行中
	 * @param call
	 */
	function onCallEstablished(call)
	{
	    log("Call established." , "blue");
	    
//	    // Handle UI changes. Call in progress.
//	    document.getElementById("make-call").disabled = true;
//	    document.getElementById("mute-call").disabled = false;
//	    document.getElementById("hold-call").disabled = false;
//	    document.getElementById("end-call").disabled = false;
	}

	function onCallStateChanged()
	{

	}

	/**
	 * 用户登录
	 */
	function userLogin()
	{
	    if(!isLogin)    //判断用户是否已经登录
	    {
	        var projectAPIKey = $("#prokey").text();
	        var username = $("#userid").text(); 
	        var password = $("#userpw").text(); 
	        kandy.login(projectAPIKey, username, password, onLoginSuccess, log("LoginFail" , "red"));
	    }
	    else
	        log("该用户已经登录" , "red");
	}

	/**
	 * 登录成功回调函数
	 */
	function onLoginSuccess()
	{
	    isLogin = true;
		if(curConferenceId == 0) {
			startConference();
		}
		else
			joinConference();
	    log("LoginSuccess" , "blue");
	}

	/**
	 * 用户注销
	 */
	function userLogout()
	{
	    if(isLogin)    //判断用户是否已经登录
	        kandy.logout(onLogout);
	    else
	        log("该用户未登录，无法注销" , "red");
	}

	/**
	 * 用户注销成功回调函数
	 */
	function onLogout()
	{
	    isLogin = false;
	    log("用户注销成功" , "blue");
	}

	/**
	 * 开始呼叫
	 */
	function startCall()
	{
//	    var callee = document.getElementById("callee").value;
//	    kandy.call.makeCall(callee, showVideo);
	}

	/**
	 * 呼叫静音
	 */
	function toggleMute()
	{
//	    if(isMuted) //解除静音
//	    {
//	        kandy.call.unMuteCall(callId);
//	        log("Unmuting call." , "blue");
//	        isMuted = false;
//	    }
//	    else    //开启静音
//	    {
//	        kandy.call.muteCall(callId);
//	        log("Muting call." , "blue");
//	        isMuted = true;
//	    }
	}

	/**
	 * 保持呼叫
	 */
	function toggleHold()
	{
//	    if(isHeld)  //解除保持
//	    {
//	        kandy.call.unHoldCall(callId);
//	        log("Unholding call." , "blue");
//	        isHeld = false;
//	    }
//	    else    //保持呼叫
//	    {
//	        kandy.call.holdCall(callId);
//	        log("Holding call." , "blue");
//	        isHeld = true;
//	    }
	}

	/**
	 * 显示关闭视频
	 */
	function toggleVideo()
	{
//	    if(showVideo)   //关闭视频
//	    {
//	        kandy.call.stopCallVideo(callId);
//	        log("Stopping send of video." , "blue");
//	        showVideo = false;
//	    }
//	    else    //开启视频
//	    {
//	        kandy.call.startCallVideo(callId);
//	        log("Starting send of video." , "blue");
//	        showVideo = true;
//	    }
	}

	/**
	 * 呼叫结束
	 */
	function endCall()
	{
	    kandy.call.endCall(callId);
	}

	/**
	 * 同意接收呼叫
	 */
	function acceptCall()
	{
	    // Tell Kandy to answer the call.
//	    kandy.call.answerCall(callId, showVideo);
//	    // Second parameter is false because we are only doing voice calls, no video.
//	    log("Call answered." , "blue");
//	    // Handle UI changes. Call no longer incoming.
//	    document.getElementById("accept-call").disabled = true;
//	    document.getElementById("decline-call").disabled = true;
	}

	/**
	 * 拒绝接受呼叫
	 */
	function declineCall()
	{
//	    // Tell Kandy to reject the call.
//	    kandy.call.rejectCall(callId); log("Call rejected.");
//	    // Handle UI changes. Call no longer incoming.
//	    document.getElementById("accept-call").disabled = true;
//	    document.getElementById("decline-call").disabled = true;
	}

	function startConference()
	{
	    kandy.conference.createConference(onStartConferenceSuccess,onStartConferenceFailure);
	}

	function onStartConferenceSuccess(conference) {
	    curConferenceId = conference.conferenceId;
	    //回写数据库信息
	    var serialno = $("#serialno").text();
	    $.ajax({ url: "/SogoInterface/servlet/WriteMeetingRoomAction?serialno=" + serialno + "&room=" + curConferenceId , 
	    	async:false, 
	    	context: document.body, 
	    	success: function(){$("#room").text(curConferenceId);
	      }});
	    joinConference();
	    log("onStartConferenceSuccess" + curConferenceId , "blue");
	}

	// What to do on a failed login.
	function onStartConferenceFailure() {
	    log("onStartConferenceFailure." , "red");
	}

	function joinConference(){
		if(!curConferenceId){
	        log("curConferenceId == null" , "red");
	        return;
	    }
	    log("ReadyJoin" , "blue");
	    kandy.conference.joinConference(
	        curConferenceId,
	        true,
	        "HWZ",
	        onJoinConferenceSuccess,
	        onJoinConferenceFailure,
	        {
	            remoteVideoContainer: document.getElementById("remoteVedio"),
	            localVideoContainer: document.getElementById("localVedio")
	        }
	    );
	}

	function onJoinConferenceSuccess() {
	    log("onJoinConferenceSuccess" , "blue");
	}

	// What to do on a failed login.
	function onJoinConferenceFailure() {
	    log("onJoinConferenceFailure." , "red");
	}
	
	/**
	 * 结束视频会议
	 */
	function endConference(){
		if(!curConferenceId){
	        log("curConferenceId == null" , "red");
	        return;
	    }
	    log("Ready endConference." , "blue");
	    kandy.conference.endConference(
	        curConferenceId,
	        onEndConferenceSuccess,
	        onEndConferenceFailure
	    );
	}

	function onEndConferenceSuccess() {
		log("onEndConferenceSuccess" , "blue");
		//leaveConference();	//离开会议室
//	    document.getElementById("make-call").disabled = false;
//	    document.getElementById("mute-call").disabled = true;
//	    document.getElementById("hold-call").disabled = true;
//	    document.getElementById("end-call").disabled = true;
	}

	// What to do on a failed login.
	function onEndConferenceFailure() {
	    log("onEndConferenceFailure." , "red");
	}

	/**
	 * 离开视频会议
	 */
	function leaveConference(){
	    if(!curConferenceId){
	        log("curConferenceId == null" , "red");
	        return;
	    }
	    log("Ready leaveConference." , "blue");
	    kandy.conference.leaveConference(
	        curConferenceId,
	        onLeaveConferenceSuccess,
	        onLeaveConferenceFailure
	    );
	}

	function onLeaveConferenceSuccess() {
	    log("onLeaveConferenceSuccess" , "blue");
	    //userLogout();	//注销用户
//	    document.getElementById("make-call").disabled = false;
//	    document.getElementById("mute-call").disabled = true;
//	    document.getElementById("hold-call").disabled = true;
//	    document.getElementById("end-call").disabled = true;
	}

	// What to do on a failed login.
	function onLeaveConferenceFailure() {
	    log("onLeaveConferenceFailure." , "red");
	}
	
	window.onbeforeunload=function(){
		endConference();
		leaveConference();	//离开会议室
		userLogout();		//注销用户
	}
});








