import clinic.utils.HttpUtil;


public class HttpPostTest {
	public static void main(String[] args) {
		String url = null;
		String param = null;
		try {
			url = "http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByCnmiaReceiverServlet";
			param = "{\"loginname\":\"用户名\",\"sqdh\":\"申请单号\"}";
			HttpUtil.post(url, param);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
