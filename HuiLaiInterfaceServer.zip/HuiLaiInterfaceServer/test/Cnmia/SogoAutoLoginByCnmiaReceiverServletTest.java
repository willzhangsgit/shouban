package Cnmia;

import clinic.utils.HttpUtil;

public class SogoAutoLoginByCnmiaReceiverServletTest {
	public static void main(String[] args) {
		String url = null;
		String param = null;
		try {
			//url = "http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByCnmiaReceiverServlet";
			url = "http://www.allhealth.com.cn:9998/SogoInterface/servlet/SogoAutoLoginByCnmiaReceiverServlet";
			param = "{\"loginname\":\"yzxzbyy\",\"sqdh\":\"3\"}";
			HttpUtil.post(url, param);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}