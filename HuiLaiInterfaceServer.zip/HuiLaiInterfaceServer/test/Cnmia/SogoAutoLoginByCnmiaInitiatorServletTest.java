package Cnmia;

import clinic.utils.HttpUtil;

public class SogoAutoLoginByCnmiaInitiatorServletTest {
	public static void main(String[] args) {
		String url = null;
		StringBuffer param = null;
		try {
			//url = "http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByCnmiaInitiatorServlet";
			url = "http://www.allhealth.com.cn:9998/SogoInterface/servlet/SogoAutoLoginByCnmiaInitiatorServlet";
			param = new StringBuffer();
			param.append("{");
			param.append("\"brxm\":\"姓名\",");
			param.append("\"brxb\":\"男\",");
			param.append("\"sfzh\":\"112233\",");
			param.append("\"lxdh\":\"电话\",");
			param.append("\"loginname\":\"hlzj\",");
			param.append("\"ycyybh\":\"远程医院编号\",");
			param.append("\"ycyymc\":\"远程医院名称\",");
			param.append("\"ycksbh\":\"远程科室编号\",");
			param.append("\"ycksmc\":\"远程科室名称\",");
			param.append("\"fqyybh\":\"发起医院编号\",");
			param.append("\"fqyymc\":\"发起医院名称\",");
			param.append("\"fqksbh\":\"发起科室编号\",");
			param.append("\"fqksmc\":\"发起科室名称\",");
			param.append("\"qsrq\":\"期望会诊日期\",");
			param.append("\"sqdh\":\"3\"");
			param.append("}");
			HttpUtil.post(url, param.toString());
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}