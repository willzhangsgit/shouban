package Cnmia;

import WebService.Cnmia.getVideoUrlService;

public class getVideoUrlServiceTest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		getVideoUrlService gl = new getVideoUrlService();
		String  setxml="{Serial:\"20170921212022817043\" ,Partners:[\"北京大学人民医院\",\"上海第一人民医院\"] ," +
				"IllCase:{Patient:\"张三\" ,Gender: \"男\",Age:26 ,Department:\"内科\" ,Diagnosis:\" 支哮，急性左心衰\", " +
				"ChiefComplaint:\"阵发性气紧、呼吸困难半天\", IllCase:\" 1型糖尿病多年，此次已有酮酸表现\" ,IllHistory:\" 肺结核病史（20余年前），慢性咳嗽病史\" ," +
				"FamilyCase:\" 糖尿病病史\", Physical:\" 支气管扩张剂及静脉激素\" ,Accessory:\" 双肺可闻及哮鸣音，偶闻吸细湿罗音\",Treatment:\"缓解血压\" }}";
		System.out.println(setxml);
		String rtn=gl.run(setxml);
		System.out.println(rtn);
	}
}
