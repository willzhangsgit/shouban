
public class StringTest {
	public static void main(String args[]) {
		String aa = "该妇2005年足月顺产一女婴，2015年下半年再婚至今，目前夫妻无小孩，2015年下半年怀孕2月，胚停 男方精液检查：精子活动度低";
		System.out.println(aa);
		String bb = aa.replace("\r\n", "");
		bb = bb.replace("\r", "");
		bb = bb.replace("\n", "");
		bb = bb.replace(" ", "");
		System.out.println(bb);
	}
}
