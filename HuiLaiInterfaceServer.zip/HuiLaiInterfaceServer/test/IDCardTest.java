import clinic.utils.IDCardUtil;


public class IDCardTest {
	public static void main(String args[]) {
		System.out.println(IDCardUtil.Verify("32108119720405631X"));
	}
}
