package DAO;

import java.sql.Connection;

import clinic.entity.Cnmia.CnmiaMeetingInfo;
import clinic.entity.Cnmia.CnmiaUserInfo;

public interface ICnmiaDAO {
	/**
	 * 根据第三方的Serialno查询视频对应的会议室
	 * @param conn
	 * @param Serialno
	 * @return
	 * @throws Exception
	 */
	public String queryMeetingRoomBySerialno(Connection conn , String Serialno) throws Exception;
	
	/**
	 * 查询可用用户信息
	 * @param conn
	 * @param prokey
	 * @return
	 * @throws Exception
	 */
	public CnmiaUserInfo queryMeetingUser(Connection conn , String prokey) throws Exception;
	
	/**
	 * 写入数据库会议记录
	 * @param conn
	 * @param room   视频供应商提供的会议室好
	 * @param serialno  第三方提供的唯一会议号
	 * @return
	 * @throws Exception
	 */
	public int writeMeetingRoom(Connection conn , String room , String serialno) throws Exception;
	
	/**
	 * 获取会议参数信息
	 * @param conn
	 * @param serialno
	 * @return
	 * @throws Exception
	 */
	public CnmiaMeetingInfo queryMeetingInfo(Connection conn , String serialno) throws Exception;
	
	/**
	 * 写入会议信息内容
	 * @param conn
	 * @param meetinfo
	 * @return
	 * @throws Exception
	 */
	public int writeMeetingInfo(Connection conn , CnmiaMeetingInfo meetinfo) throws Exception;
	
	/**
	 * 添加用户、权限、医院、部门信息（判断用户是否存在）
	 * @param conn
	 * @param userlogin
	 * @param username
	 * @param cookie_token
	 * @return
	 * @throws Exception
	 */
	public String addCnmiaUserInfo(Connection conn , String userlogin , String username) throws Exception;
	/**
	 * 判断非公这个单据号是否已经绑定过我们的单据信息
	 * @param conn
	 * @param cnmYyid
	 * @return
	 * @throws Exception
	 */
	public boolean existsYyinfo(Connection conn , String cnmYyid) throws Exception;
	/**
	 * 新增非公和我们申请的绑定信息
	 * @param conn
	 * @param cnmYyid
	 * @param sogoYyid
	 * @throws Exception
	 */
	public void addYyinfo(Connection conn , String cnmYyid , String sogoYyid) throws Exception;
	/**
	 * 修改非公和我们申请单的绑定信息
	 * @param conn
	 * @param cnmYyid
	 * @param sogoYyid
	 * @throws Exception
	 */
	public void updateYyinfo(Connection conn , String cnmYyid , String sogoYyid) throws Exception;
	/**
	 * 根据非公的YYID查询我们的YYID
	 * @param conn
	 * @param cnmYyid
	 * @return
	 * @throws Exception
	 */
	public String queryYyidByCnmyyid(Connection conn , String cnmYyid) throws Exception;
	/**
	 * 根据YYID获取病人PID
	 * @param conn
	 * @param yyid
	 * @return
	 * @throws Exception
	 */
	public String queryPidByYyid(Connection conn , String yyid) throws Exception;
}
