package DAO;

import java.sql.Connection;

import clinic.entity.HuiLai.HtdPatientInfo;

public interface IHuiLaiDAO {
	/**
	 * 查询密码
	 * @param conn
	 * @param username
	 * @return
	 * @throws Exception
	 */
	public String queryUserPassword(Connection conn ,String username) throws Exception;
	/**
	 * 判断病人是否存在
	 * @param conn
	 * @param sfzh
	 * @return
	 * @throws Exception
	 */
	public boolean existsPatInfo(Connection conn , String sfzh) throws Exception;
	/**
	 * 创建病人信息
	 * @param conn
	 * @param patinfo
	 * @return  病人PID
	 * @throws Exception
	 */
	public String createPatInfo(Connection conn , HtdPatientInfo patinfo) throws Exception;
	/**
	 * 查询患者信息
	 * @param conn
	 * @param sfzh
	 * @return
	 * @throws Exception
	 */
	public HtdPatientInfo queryPatInfo(Connection conn, String sfzh) throws Exception;
}
