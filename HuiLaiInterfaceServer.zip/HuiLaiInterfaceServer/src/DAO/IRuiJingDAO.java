package DAO;
import java.sql.Connection;
import java.util.List;

import clinic.entity.HuiLai.HtdBookingApply;
import clinic.entity.HuiLai.HtdBookingInfo;
import clinic.entity.ruijing.HtdRjKsxxNew2;;

public interface IRuiJingDAO {
	/**
	 * 查询预约瑞金的有效会诊单
	 * @param conn
	 * @param st
	 * @param et
	 * @return
	 * @throws Exception
	 */
	public List<HtdBookingInfo> queryRuiJingBookInfo(Connection conn , String st , String et)  throws Exception;
	
	/**
	 * 写入瑞金会诊上传日志表
	 * @param conn
	 * @param info
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int insertRuiJingCommitLog(Connection conn , HtdBookingInfo info , int id) throws Exception;
	
	/**
	 * 更新瑞金会诊上传日志表的输入参数字段
	 * @param conn
	 * @param inputparam
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int updateRuiJingCommitLogInputParam(Connection conn , String inputparam , int id) throws Exception;
	
	/**
	 * 更新瑞金会诊上传日志表的结果
	 * @param conn
	 * @param result
	 * @param hzid
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int updateRuiJingCommitLogResult(Connection conn , String result , String hzid , int id , String output) throws Exception;
	
	/**
	 * 查询预约申请单信息
	 * @param conn
	 * @param yyid
	 * @return
	 * @throws Exception
	 */
	public HtdBookingApply queryRuiJingBookApply(Connection conn , String yyid) throws Exception;

	/**
	 * 获取现在之后的取消预约的申请信息
	 * @param conn
	 * @param st
	 * @return
	 * @throws Exception
	 */
	public List<HtdBookingInfo> queryCancelBookingInfo(Connection conn , String st) throws Exception;	
	
	/**
	 * 根据瑞金会诊ID更新状态
	 * @param conn
	 * @param hzid
	 * @param status
	 * @return
	 * @throws Exception
	 */
	public int updateRuiJingCommitLogStatus(Connection conn , String hzid , int status) throws Exception;

	public int insertRuiJingKsxx(Connection conn ,HtdRjKsxxNew2 ksxx, String ourid);

	public String queryRuiJingOurid(Connection conn, String name); 
}
