package DAO.Impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import DAO.IHuiLaiDAO;
import clinic.entity.HuiLai.HtdBookingInfo;
import clinic.entity.HuiLai.HtdPatientInfo;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.Util;

public class HuiLaiDAOImpl extends BaseEntity implements IHuiLaiDAO {
	public String queryUserPassword(Connection conn ,String username) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String rtn = null;
		int i = 1;
		try {
			sql = "SELECT PASSWORD FROM ESF.SPT_USER WHERE LOGIN_NAME = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, username);
			rs = pstmt.executeQuery();
			if(rs.next())
				rtn = rs.getString("PASSWORD");
		} catch(Exception ex) {
			
		} finally {
			
		} 
		return rtn;
	}
	
	public boolean existsPatInfo(Connection conn , String sfzh) throws Exception {
		boolean rtn = false;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = " SELECT COUNT(*) AS NUM FROM HUILAI.HTD_PATIENT_INFO WHERE SFZH = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sfzh);
			rs = pstmt.executeQuery();
			rs.next();
			if(rs.getInt("NUM") > 0)
				rtn = true;
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public String createPatInfo(Connection conn , HtdPatientInfo patinfo) throws Exception {
		String rtn = null;
		CallableStatement pstm = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL HUILAI.USP_ADD_PATIENT(?,?,?,?,?,?,?,?)}");
			pstm.setString(i++, patinfo.getXm());
			pstm.setString(i++, patinfo.getXb());
			pstm.setString(i++, "1");
			pstm.setString(i++, patinfo.getSfzh());
			pstm.setString(i++, patinfo.getCsrq());
			pstm.setString(i++, patinfo.getSjh());
			pstm.setString(i++, patinfo.getDz());
			pstm.registerOutParameter(i++, Types.VARCHAR);	//pid
			pstm.execute();
			rtn = pstm.getString(8);
			if(Util.strIsNullOrEmpty(rtn))
				throw new Exception("创建病人信息失败");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstm, null);
		}
		return rtn;
	}
	
	public HtdPatientInfo queryPatInfo(Connection conn, String sfzh) throws Exception {
		HtdPatientInfo rtn = null;
		List<HtdPatientInfo> ls = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int i=1;
		try {
			sql = " SELECT * FROM HUILAI.HTD_PATIENT_INFO WHERE SFZH = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sfzh);
			rs = pstmt.executeQuery();
			ls = RsToList(rs, HtdPatientInfo.class, null, null);
			if(ls != null && ls.size() == 1) 
				rtn = ls.get(0);
		} catch(Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
}
