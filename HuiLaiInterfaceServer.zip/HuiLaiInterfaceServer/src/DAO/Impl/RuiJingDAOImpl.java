package DAO.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import clinic.entity.HuiLai.HtdBookingApply;
import clinic.entity.HuiLai.HtdBookingInfo;
import clinic.entity.ruijing.HtdRjKsxxNew2;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import DAO.IRuiJingDAO;

public class RuiJingDAOImpl extends BaseEntity implements IRuiJingDAO {
	public List<HtdBookingInfo> queryRuiJingBookInfo(Connection conn ,String st , String et)  throws Exception {
		List<HtdBookingInfo> rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int i=1;
		try {
			BaseEntity.SetRuiJingConfigParam2();
			sql = "SELECT C.XM , C.SFZH ,D.USER_NAME AS FQYSXM,HUILAI.F_GET_YYXM(A.FQHOSPNO) AS FQHOSPNAME , " +
				 " E.RJKSBH, E.RJKSMC , E.PARENT_ID , A.* " +
				 " FROM HUILAI.HTD_BOOKING_INFO A , HUILAI.HTD_BOOKING_DETAIL B , " +
				 " HUILAI.HTD_PATIENT_INFO C , ESF.SPT_USER D , HUILAI.HTD_RJ_KSXX_NEW2 E " +
				 " WHERE A.YYID = B.YYID AND A.PID = C.PID AND A.FQYSID = D.USER_ID AND B.YYKSBH = E.OURDEPTID " +
				 " AND A.YYID NOT IN (SELECT YYID FROM HUILAI.HTD_RJ_HZ_COMMIT_NEW2_LOG WHERE OPTIME >= ? AND OPTIME <= ? )" +
				 " AND A.SQTJSJ >= ? AND A.SQTJSJ <= ? " +
				 " AND YYZT = ? AND JZZT = ? AND A.STATUS = ? " +
				 " AND B.YYYYID = ? " +
				 " and B.yyksbh not in ('31010100301','31010100384') "; //add by will MDT多学科会诊和不孕不育科 不上传
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, st);
			pstmt.setString(i++, et);
			pstmt.setString(i++, st);
			pstmt.setString(i++, et);
			pstmt.setInt(i++, RuiJingConfigParam.getYyzt());
			pstmt.setInt(i++, RuiJingConfigParam.getJzzt());
			pstmt.setInt(i++, 1);
			pstmt.setString(i++, RuiJingConfigParam.getBdrjyybh());
			rs = pstmt.executeQuery();
			rtn = RsToList(rs, HtdBookingInfo.class, null, null);
		} catch(Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public int insertRuiJingCommitLog(Connection conn , HtdBookingInfo info , int id) throws Exception {
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			sql = "INSERT INTO HUILAI.HTD_RJ_HZ_COMMIT_NEW2_LOG(ID , YYID , OPTIME ) VALUES (? , ? , SYSDATE())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(i++, id);
			pstmt.setString(i++, info.getYyid());
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("写入瑞金会诊上传日志表失败：HTD_RJ_HZ_COMMIT_NEW2_LOG");
		} catch(Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public int updateRuiJingCommitLogInputParam(Connection conn , String inputparam , int id) throws Exception {
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			sql = "UPDATE HUILAI.HTD_RJ_HZ_COMMIT_NEW2_LOG SET INPUTPARAM = ? WHERE ID = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, inputparam);
			pstmt.setInt(i++, id);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("更新瑞金会诊上传日志表输入参数失败：HTD_RJ_HZ_COMMIT_NEW2_LOG");
		} catch(Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public int updateRuiJingCommitLogResult(Connection conn , String result , String hzid , int id , String output) throws Exception {
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			sql = "UPDATE HUILAI.HTD_RJ_HZ_COMMIT_NEW2_LOG SET RESULT = ? , RJ_HZID = ? , OUTPUT = ? WHERE ID = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, result);
			pstmt.setString(i++, hzid);
			pstmt.setString(i++, output);
			pstmt.setInt(i++, id);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("更新瑞金会诊上传日志表返回结果失败：HTD_RJ_HZ_COMMIT_NEW2_LOG");
		} catch(Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public HtdBookingApply queryRuiJingBookApply(Connection conn , String yyid) throws Exception {
		List<HtdBookingApply> applyls = null;
		HtdBookingApply rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int i=1;
		try {
			BaseEntity.SetRuiJingConfigParam();
			sql = "SELECT IFNULL(YYID , '无') AS YYID , IFNULL(LCZD , '无') AS LCZD , IFNULL(ZS , '无') AS ZS , IFNULL(XBS , '无') AS XBS , " +
				 " IFNULL(JWS , '无') AS JWS , IFNULL(JZS , '无') AS JZS , IFNULL(TGJC , '无') AS TGJC , IFNULL(FZJC , '无') AS FZJC , " +
				 " IFNULL(ZLGC , '无') AS ZLGC , IFNULL(HZMD , '无') AS HZMD " +
				 " FROM HUILAI.HTD_BOOKING_APPLY WHERE YYID = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, yyid);
			rs = pstmt.executeQuery();
			applyls = RsToList(rs, HtdBookingApply.class, null, null);
			if(applyls != null && applyls.size() == 1)
				rtn = applyls.get(0);
			else 
				rtn = new HtdBookingApply();
		} catch(Throwable t) {
			rtn = null;
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public List<HtdBookingInfo> queryCancelBookingInfo(Connection conn , String st) throws Exception {
		List<HtdBookingInfo> rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int i=1;
		try {
			BaseEntity.SetRuiJingConfigParam();
			sql = "SELECT B.RJ_HZID AS RJHZID " +
				 " FROM HUILAI.HTD_BOOKING_INFO A , HUILAI.htd_rj_hz_commit_new2_log B " +
				 " WHERE A.YYID = B.YYID AND  A.YYZT = ? " +
				 " AND A.YYJZSJ >= ? AND B.STATUS = ? AND B.RESULT = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(i++, 5);
			pstmt.setString(i++, st);
			pstmt.setInt(i++, 1);
			pstmt.setString(i++, "00");
			rs = pstmt.executeQuery();
			rtn = RsToList(rs, HtdBookingInfo.class, null, null);
		} catch(Throwable t) {
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public int updateRuiJingCommitLogStatus(Connection conn , String hzid , int status) throws Exception {
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			sql = "UPDATE HUILAI.HTD_RJ_HZ_COMMIT_LOG SET STATUS = ? , CANCELTIME = SYSDATE() WHERE RJ_HZID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(i++, status);
			pstmt.setString(i++, hzid);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("更新瑞金会诊上传日志表状态失败：HTD_RJ_HZ_COMMIT_LOG");
		} catch(Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public int updateRuiJingCommitLogStatus2(Connection conn , String hzid , int status) throws Exception {
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			sql = "UPDATE HUILAI.HTD_RJ_HZ_COMMIT_NEW2_LOG SET STATUS = ? , CANCELTIME = SYSDATE() WHERE RJ_HZID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(i++, status);
			pstmt.setString(i++, hzid);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("更新瑞金会诊取消日志表状态失败：HTD_RJ_HZ_COMMIT_NEW2_LOG");
		} catch(Throwable t) {
			t.printStackTrace();
			throw new Exception(t.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}

	@Override
	public int insertRuiJingKsxx(Connection conn, HtdRjKsxxNew2 info, String ourid) {
		// TODO Auto-generated method stub
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		int rtn = 0;
		try {
			//conn = DBUtils.GetConn();
			sql = "INSERT INTO HUILAI.HTD_RJ_KSXX_NEW2(rjKsbh, rjKsmc, HOSPITAL_ID, PARENT_ID, DESCRIPTION, ourDeptId , OPTIME ) VALUES (?, ?, ?, ?, ?, ?, SYSDATE())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, info.getRjKsbh());
			pstmt.setString(i++, info.getRjKsmc());
			pstmt.setString(i++, info.getHOSPITAL_ID());
			pstmt.setString(i++, info.getPARENT_ID());
			pstmt.setString(i++, info.getDESCRIPTION());
			pstmt.setString(i++, ourid);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("写入瑞金会诊上传科室同步失败：HTD_RJ_KSXX_NEW2");
		} catch(Throwable t) {
			t.printStackTrace();
		} finally {
			DBUtils.closeConn(null, pstmt, conn);
		}
		return rtn;
	}

	@Override
	public String queryRuiJingOurid(Connection conn, String name) {
		// TODO Auto-generated method stub
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		String rtn = null;
		int i = 1;
		try {
			sql = "select DEPT_ID from ESF.SPT_DEPT where ORGAN_ID='310101003' and DEPT_NAME=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, name);
			rs = pstmt.executeQuery();
			if(rs.next())
				rtn = rs.getString("DEPT_ID");
		} catch(Exception ex) {
			
		} finally {
			
		} 
		return rtn;
	}
}
