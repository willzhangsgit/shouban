package DAO.Impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import DAO.IXueTouTongDAO;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;

public class XueTouTongDAOImpl extends BaseEntity implements IXueTouTongDAO {
	
	public String addUserInfo(Connection conn , String userlogin , String username , String cookie_token) throws Exception {
		String rtn = null;
		CallableStatement pstm = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL HUILAI.USP_ADD_XUE_TOU_TONG_USER(?,?,?,?)}");
			pstm.setString(i++, userlogin);
			pstm.setString(i++, username);
			pstm.setString(i++, cookie_token);
			pstm.registerOutParameter(i++, Types.VARCHAR);
			pstm.execute();
			rtn = pstm.getString(4);
			if(!rtn.equals("1"))
				throw new Exception(rtn);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstm, null);
		}
		return rtn;
	}
	
	public String queryXueTouTongToken(Connection conn) throws Exception {
		String rtn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = "SELECT TOKEN FROM HUILAI.XUE_TOU_TONG_USER_TOKEN ORDER BY OPTIME DESC";
			pstm = conn.prepareStatement(sql);
			rs = pstm.executeQuery();
			if(rs.next())
				rtn = rs.getString("TOKEN");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstm, null);
		}
		return rtn;
	}
}
