package DAO.Impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import clinic.entity.Cnmia.CnmiaMeetingInfo;
import clinic.entity.Cnmia.CnmiaUserInfo;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import DAO.ICnmiaDAO;

public class CnmiaDAOImpl extends BaseEntity implements ICnmiaDAO {
	public String queryMeetingRoomBySerialno(Connection conn , String Serialno) throws Exception {
		String rtn = null;
		CallableStatement pstm = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL CNMIA.USP_GETMEETINGROOM(?,?,?,?)}");
			pstm.setString(i++, Serialno);
			pstm.registerOutParameter(i++, Types.VARCHAR);
			pstm.registerOutParameter(i++, Types.INTEGER);
			pstm.registerOutParameter(i++, Types.VARCHAR);
			pstm.execute();
			rtn = pstm.getString(2);
			i = pstm.getInt(3);
			if(i == -1)
				throw new Exception(pstm.getString(4));
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstm, null);
		}
		return rtn;
	}
	
	public CnmiaUserInfo queryMeetingUser(Connection conn , String prokey) throws Exception {
		List<CnmiaUserInfo> users = null;
		CallableStatement pstm = null;
		ResultSet rs = null;
		CnmiaUserInfo rtn = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL CNMIA.USP_GETMEETINGUSER(?)}");
			pstm.setString(i++, prokey);
			pstm.execute();
			rs = pstm.getResultSet();
			users = RsToList(rs , CnmiaUserInfo.class , null , null);
			if(users == null || users.size() == 0)
				throw new Exception("没有找到对应的用户信息");
			rtn = users.get(0);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstm, null);
		}
		return rtn;
	}
	
	public int writeMeetingRoom(Connection conn , String room , String serialno) throws Exception {
		int rtn = 0;
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		try {
			sql = "INSERT INTO CNMIA.CNM_MEETING_ROOM ( ID , SERIALNO , MEETROOM , CREATEROOMTIME)" +
				 " VALUE ( CNMIA._NEXTVAL(?), ? , ? , NOW())";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, "id");
			pstmt.setString(i++, serialno);
			pstmt.setString(i++, room);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("写入会议室表失败");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public CnmiaMeetingInfo queryMeetingInfo(Connection conn , String serialno) throws Exception {
		List<CnmiaMeetingInfo> infos = null;
		CallableStatement pstm = null;
		ResultSet rs = null;
		CnmiaMeetingInfo rtn = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL CNMIA.USP_GETMEETINGINFO(?)}");
			pstm.setString(i++, serialno);
			pstm.execute();
			rs = pstm.getResultSet();
			infos = RsToList(rs , CnmiaMeetingInfo.class , null , null);
			if(infos == null || infos.size() == 0)
				throw new Exception("没有找到对应的会议内容信息");
			rtn = infos.get(0);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstm, null);
		}
		return rtn;
	}
	
	public int writeMeetingInfo(Connection conn , CnmiaMeetingInfo meetinfo) throws Exception {
		int rtn = 0;
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		try {
			sql = "INSERT INTO CNMIA.CNM_MEETING_INFO(ID , SERIAL , PARTNERS , PATIENT , GENDER , " +
				 " AGE , DEPARTMENT , DIAGNOSIS , CHIEFCOMPLAINT , ILLCASE , ILLHISTORY , FAMILYCASE , " +
				 " PHYSICAL , ACCESSORY , TREATMENT ) " +
				 " VALUE ( CNMIA._NEXTVAL(?), ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, "id");
			pstmt.setString(i++, meetinfo.getSerial());
			pstmt.setString(i++, meetinfo.getPartners());
			pstmt.setString(i++, meetinfo.getPatient());
			pstmt.setString(i++, meetinfo.getGender());
			pstmt.setString(i++, meetinfo.getAge());
			pstmt.setString(i++, meetinfo.getDepartment());
			pstmt.setString(i++, meetinfo.getDiagnosis());
			pstmt.setString(i++, meetinfo.getChiefcomplaint());
			pstmt.setString(i++, meetinfo.getIllcase());
			pstmt.setString(i++, meetinfo.getIllhistory());
			pstmt.setString(i++, meetinfo.getFamilycase());
			pstmt.setString(i++, meetinfo.getPhysical());
			pstmt.setString(i++, meetinfo.getAccessory());
			pstmt.setString(i++, meetinfo.getTreatment());
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("写入会议室内容失败");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
		return rtn;
	}
	
	public String addCnmiaUserInfo(Connection conn , String userlogin , String username) throws Exception {
		String rtn = null;
		CallableStatement pstm = null;
		int i=1;
		try {
			pstm = conn.prepareCall("{ CALL CNMIA.USP_ADD_CNMIA_USER(?,?,?)}");
			pstm.setString(i++, userlogin);
			pstm.setString(i++, username);
			pstm.registerOutParameter(i++, Types.VARCHAR);
			pstm.execute();
			rtn = pstm.getString(3);
			if(!rtn.equals("1"))
				throw new Exception(rtn);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstm, null);
		}
		return rtn;
	}
	
	public boolean existsYyinfo(Connection conn , String cnmYyid) throws Exception {
		boolean rtn = false;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = "SELECT COUNT(*) AS NUM FROM CNMIA.CNM_YY_INFO WHERE CNM_YYID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cnmYyid);
			rs = pstmt.executeQuery();
			rs.next();
			if(rs.getInt("NUM") > 0)
				rtn = true;
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public void addYyinfo(Connection conn , String cnmYyid , String sogoYyid) throws Exception {
		int rtn = 0;
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		try {
			sql = "INSERT INTO CNMIA.CNM_YY_INFO(CNM_YYID , SOGO_YYID) VALUES (? , ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, cnmYyid);
			pstmt.setString(i++, sogoYyid);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("写入绑定申请单内容失败");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
	}
	
	public void updateYyinfo(Connection conn , String cnmYyid , String sogoYyid) throws Exception {
		int rtn = 0;
		PreparedStatement pstmt = null;
		String sql = null;
		int i=1;
		try {
			sql = "UPDATE CNMIA.CNM_YY_INFO SET SOGO_YYID = ? WHERE CNM_YYID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(i++, sogoYyid);
			pstmt.setString(i++, cnmYyid);
			rtn = pstmt.executeUpdate();
			if(rtn != 1)
				throw new Exception("修改绑定申请单内容失败");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(null, pstmt, null);
		}
	}
	
	public String queryYyidByCnmyyid(Connection conn , String cnmYyid) throws Exception {
		String rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = "SELECT SOGO_YYID FROM CNMIA.CNM_YY_INFO WHERE CNM_YYID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cnmYyid);
			rs = pstmt.executeQuery();
			if(rs.next())
				rtn = rs.getString("SOGO_YYID");
			else 
				rtn = "";
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
	
	public String queryPidByYyid(Connection conn , String yyid) throws Exception {
		String rtn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		try {
			sql = "SELECT PID FROM HUILAI.HTD_BOOKING_INFO WHERE YYID = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, yyid);
			rs = pstmt.executeQuery();
			if(rs.next())
				rtn = rs.getString("PID");
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		} finally {
			DBUtils.closeConn(rs, pstmt, null);
		}
		return rtn;
	}
}
