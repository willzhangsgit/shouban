package DAO;

import java.sql.Connection;

public interface IXueTouTongDAO {
	/**
	 * 添加用户、权限、医院、部门信息（判断用户是否存在）
	 * @param conn
	 * @param userlogin
	 * @param username
	 * @param cookie_token
	 * @return
	 * @throws Exception
	 */
	public String addUserInfo(Connection conn , String userlogin , String username , String cookie_token) throws Exception;
	
	/**
	 * 获取最新的TOKEN
	 * @param conn
	 * @return
	 * @throws Exception
	 */
	public String queryXueTouTongToken(Connection conn) throws Exception;
}
