package WebService.Cnmia;

import java.sql.Connection;
import org.json.JSONObject;

import DAO.ICnmiaDAO;
import Domain.CnmiaDomain;
import clinic.entity.Cnmia.CnmiaMeetingInfo;
import clinic.factory.DomainDAOFactory;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.JasonParamUtil;

public class getVideoUrlService extends BaseEntity {
	public String run(String params) {
		System.out.println("CnmiaService01");
		String rtn = null;
		JSONObject dataJson = null;
		Connection conn = null;
		ICnmiaDAO dao = null;
		CnmiaDomain domain = null;
		String Serial = null;
		String room = null;
		String url = "https://www.allhealth.com.cn:8567/SogoInterface/servlet/GetVideoParamAction";
		CnmiaMeetingInfo meetinfo = null;
		try {
			//获取参数
			dataJson = new JSONObject(params);
			Serial = JasonParamUtil.getJasonStringValue(dataJson, "Serial", "", true);
			//获取数据库连接
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			domain = DomainDAOFactory.getCnmianDomain();
			dao = DomainDAOFactory.getCnmiaDAO();
			//解析会议信息入库
			meetinfo = domain.getMeetingInfo(params);
			if(meetinfo == null)
				throw new Exception("解析参数失败");
			//入库参数
			dao.writeMeetingInfo(conn, meetinfo);
			//查询房间号
			room = dao.queryMeetingRoomBySerialno(conn, Serial);
			DBUtils.Commit(conn);
			//组织返回值
			url = url + "?room=" + room + "&serialno=" + Serial;
			rtn = "{Code:\"1\", Msg:\"\" ,Result:{VideoUrl:\"" + url + "\" ,RoomID: \"" + room + "\"}}";
		} catch (Exception e) {
			DBUtils.RollBack(conn);
			rtn = "{Code:\"0\", Msg:\"" + e.getMessage() + "\" ,Result:{VideoUrl:\"\" ,RoomID: \"\"}}";
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
		return rtn;
	}
}