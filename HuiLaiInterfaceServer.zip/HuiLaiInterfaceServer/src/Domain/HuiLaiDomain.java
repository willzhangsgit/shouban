package Domain;

import java.sql.Connection;

import com.sapframework.base.util.EncodeUtils;
import com.sapframework.user.util.UserUtils;
import clinic.factory.DomainDAOFactory;
import clinic.utils.Util;
import DAO.IHuiLaiDAO;

public class HuiLaiDomain {
	public String queryUserPassword(Connection conn ,String username) throws Exception {
		String rtn = null;
		IHuiLaiDAO dao = null;
		byte by[];
		try {
			dao = DomainDAOFactory.getHuiLaiDAO();
			rtn = dao.queryUserPassword(conn, username);
			if(Util.strIsNullOrEmpty(rtn))
				throw new Exception("没有找到相应的用户名密码");
			by = EncodeUtils.decodeHex(rtn);
			rtn = new String(by);
			by = EncodeUtils.decodeHex(rtn);
			rtn = new String(by);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
}
