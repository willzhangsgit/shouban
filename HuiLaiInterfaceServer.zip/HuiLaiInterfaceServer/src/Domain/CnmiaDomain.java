package Domain;

import org.json.JSONObject;

import clinic.entity.Cnmia.CnmiaMeetingInfo;
import clinic.utils.JasonParamUtil;

public class CnmiaDomain {
	/**
	 * 根据输入参数JSON，解析会议内容
	 * @param json
	 * @return
	 * @throws Exception
	 */
	public CnmiaMeetingInfo getMeetingInfo(String jsonparam) throws Exception {
		CnmiaMeetingInfo rtn = null;
		JSONObject dataJson = null;
		JSONObject illcaseJson = null;
		String partners = null;
		try {
			rtn = new CnmiaMeetingInfo();
			dataJson = new JSONObject(jsonparam);
			rtn.setSerial(JasonParamUtil.getJasonStringValue(dataJson, "Serial", "", false));
			partners = JasonParamUtil.getJasonStringValue(dataJson, "Partners", "", false);
			if(partners != null && partners.trim().length() > 0) {
				partners = partners.replace("[", "");
				partners = partners.replace("]", "");
				partners = partners.replace("\"", "");
			}
			rtn.setPartners(partners);
			illcaseJson = new JSONObject(JasonParamUtil.getJasonStringValue(dataJson, "IllCase", "", false));
			rtn.setPatient(JasonParamUtil.getJasonStringValue(illcaseJson, "Patient", "", false));
			rtn.setGender(JasonParamUtil.getJasonStringValue(illcaseJson, "Gender", "", false));
			rtn.setAge(JasonParamUtil.getJasonStringValue(illcaseJson, "Age", "", false));
			rtn.setDepartment(JasonParamUtil.getJasonStringValue(illcaseJson, "Department", "", false));
			rtn.setDiagnosis(JasonParamUtil.getJasonStringValue(illcaseJson, "Diagnosis", "", false));
			rtn.setChiefcomplaint(JasonParamUtil.getJasonStringValue(illcaseJson, "ChiefComplaint", "", false));
			rtn.setIllcase(JasonParamUtil.getJasonStringValue(illcaseJson, "IllCase", "", false));
			rtn.setIllhistory(JasonParamUtil.getJasonStringValue(illcaseJson, "IllHistory", "", false));
			rtn.setFamilycase(JasonParamUtil.getJasonStringValue(illcaseJson, "FamilyCase", "", false));
			rtn.setPhysical(JasonParamUtil.getJasonStringValue(illcaseJson, "Physical", "", false));
			rtn.setAccessory(JasonParamUtil.getJasonStringValue(illcaseJson, "Accessory", "", false));
			rtn.setTreatment(JasonParamUtil.getJasonStringValue(illcaseJson, "Treatment", "", false));
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return rtn;
	}
	
	public static void main(String args[]) {
		try {
			CnmiaDomain aa = new CnmiaDomain();
			String  setxml="{Serial:\"20170921212022817043\" ,Partners:[\"北京大学人民医院\",\"上海第一人民医院\"] ," +
					"IllCase:{Patient:\"张三\" ,Gender: \"男\",Age:26 ,Department:\"内科\" ,Diagnosis:\" 支哮，急性左心衰\", " +
					"ChiefComplaint:\"阵发性气紧、呼吸困难半天\", IllCase:\" 1型糖尿病多年，此次已有酮酸表现\" ,IllHistory:\" 肺结核病史（20余年前），慢性咳嗽病史\" ," +
					"FamilyCase:\" 糖尿病病史\", Physical:\" 支气管扩张剂及静脉激素\" ,Accessory:\" 双肺可闻及哮鸣音，偶闻吸细湿罗音\",Treatment:\"缓解血压\" }}";
			aa.getMeetingInfo(setxml);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}