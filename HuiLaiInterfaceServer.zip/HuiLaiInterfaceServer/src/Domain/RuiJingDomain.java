package Domain;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.List;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import DAO.IRuiJingDAO;
import clinic.entity.HuiLai.HtdBookingApply;
import clinic.entity.HuiLai.HtdBookingInfo;
import clinic.entity.Magnolia.ApplyReq;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.entity.ruijing.RuiJingSaveConsultationRtn;
import clinic.factory.DomainDAOFactory;
import clinic.utils.DBUtils;
import clinic.utils.IDCardUtil;
import clinic.utils.Util;

public class RuiJingDomain {
	
	/**
	 * 上传会诊申请
	 * @param conn
	 * @throws Exception
	 */
	public void sendConsultation(Connection conn) throws Exception{
		int total = 0;			//总待上传记录数
		int success = 0;		//上传成功的记录数
		int fail = 0;			//上传失败的记录数
		String sysSt = null;	//接口开始时间，打印日志使用
		String sysEt = null;	//接口完成时间，打印日志使用
		String st = null;		//当天日期  yyyy-mm-dd 00:00:00
		String et = null;		//当天日期  yyyy-mm-dd 23:59:59
		IRuiJingDAO dao = null;	//瑞金的dao
		List<HtdBookingInfo> commitlist = null;	//预约信息
		try {
			dao = DomainDAOFactory.getRuiJingDAO();
			sysSt = DBUtils.getSysdateMySQL(conn , 1);
			System.out.println(sysSt + " 开始上传瑞金会诊申请");
			//获取所有需要上传的会诊申请
			st = DBUtils.getSysdateMySQL(conn, 3);
			et = DBUtils.getSysdateMySQL(conn, 4);
			//willtest
			//st = "2019-03-26 00:00:00";
			//et = "2019-03-27 00:00:00";
			
			commitlist = dao.queryRuiJingBookInfo(conn, st, et);
			if(commitlist == null)
				 throw new Exception("查询瑞金需要上传的会诊失败");
			//循环所有会诊申请
			total = commitlist.size();
			if(false){
				commitBookingInfoTest(null);
				throw new Exception("内部测试");
			}
			if(false){
				System.out.println("战略暂停");
				String testjson = "{\"entity\": \"{\\\"UUID\\\":\\\"b816eaac-9bad-43f4-825c-c049df38495c\\\"}\"}";
				JsonParser parser = new JsonParser();  //创建JSON解析器
				JsonObject object = (JsonObject) parser.parse(testjson);  //创建JsonObject对象
				String rtnentity = object.get("entity").getAsString();  //{"UUID":"b816eaac-9bad-43f4-825c-c049df38495c"}
				String rjhzid = "";
				if(rtnentity.indexOf(":") > -1){
					rjhzid = rtnentity.split(":")[1].replaceAll("\"", "").replace("}", "").trim();
				}
				
				throw new Exception("内部测试");
			}
			for(int i=0; i<total; i++) {
				String inputparam = "";		//瑞金接口输入参数
				String restfulrtn = null;	//瑞金接口返回值
				RuiJingSaveConsultationRtn restful = null; 	//解析瑞金返回值 
				HtdBookingInfo info = commitlist.get(i);
				//获取病情信息
				HtdBookingApply apply = dao.queryRuiJingBookApply(conn, info.getYyid());
				//获取ID
				int id = DBUtils.getNextSequenceMySQL(conn, "ID");
				//写入本地日志表
				dao.insertRuiJingCommitLog(conn, info , id);
				//组织JSON数据，调用瑞金接口
				inputparam = organizeCommitJson(info , apply);
				System.out.println(inputparam);
				
				//新上传
				ApplyReq aq = new ApplyReq();
				aq = organizeCommitReq(info, apply);
				
				//更新本地日志表JSON字段
				dao.updateRuiJingCommitLogInputParam(conn, inputparam, id);
				//调用瑞金平台接口
				//restfulrtn = commitBookingInfo(inputparam); //willtest
				restfulrtn = commitBookingInfo2(aq);
				
				//restful = analyBookingRtn(restfulrtn); //willtest测试先注释		
				System.out.println(restfulrtn);
				
				restful = analyBookingRtnNew2(restfulrtn);
				//更新本地日志表上传字段 
				//dao.updateRuiJingCommitLogResult(conn, restful.getCode() , restful.getRjhzid() , id , restful.getOutput());  //willtest测试先注释				
				dao.updateRuiJingCommitLogResult(conn, restful.getCode() , restful.getRjhzid() , id , restfulrtn);
				//if(restful.getCode().equals("00"))
				if(restful.getCode().equals("SUCCESS"))
					success++;
				else
					fail++;
			}
		} catch(Throwable t) {
			fail++;
			System.out.println(t.getMessage());
		} finally {
			sysEt = DBUtils.getSysdateMySQL(conn , 1);
			System.out.println(sysEt + " 结束上传瑞金会诊申请：总条数=" + total + "，成功=" + success + "，失败=" + fail);
		}
	}
	
	private ApplyReq organizeCommitReq(HtdBookingInfo info, HtdBookingApply apply) {
		// TODO Auto-generated method stub
		int age = -1;
		String sex = null;
		ApplyReq rtn = new ApplyReq();
		try {
			if(info != null && (!Util.strIsNullOrEmpty(info.getSfzh()))) {
				age = IDCardUtil.getAgeBySfzh(info.getSfzh());
				if(age <= 0)
					throw new Exception("从身份证获取年龄信息失败");
				sex = IDCardUtil.getSexBySfzh(info.getSfzh());
				if(Util.strIsNullOrEmpty(sex)) 
					throw new Exception("从身份证获取性别信息失败");
				else if(sex.trim().equals("男"))
					sex = "boy";
				else if(sex.trim().equals("女"))
					sex = "girl"; //?
				else 
					sex = "unknown"; //?
				//患者信息
				rtn.setConsultationType("clinical");
				//rtn.setThirdSourceId("2");  //?
				//rtn.setThirdApplyId("100"); //?
				//rtn.setThirdSourceUUID("c65186fc-ff3c-4fbc-ae05-7232421c4dbb"); 测试环境
				rtn.setThirdSourceUUID("4feeb452-0e69-4651-89d0-95c902d07fde");
				rtn.setThirdHospitalName(info.getFqhospname()); //?
				rtn.setConsultationWay("general"); //?
				rtn.setServerInstiuttionId("1"); //?
				rtn.setServerInstiuttionUUID("c8453a37-991a-429d-be1e-4520e729c043");
				if(!Util.strIsNullOrEmpty(info.getYyjzsj())) {
					//if(info.getYyjzsj().endsWith(".0"))
						//rtn.setAppointTime(info.getYyjzsj().substring(0, info.getYyjzsj().length() - 2));
					//rtn.setAppointTime(info.getYyjzsj());	//期望会诊时间
					String infoDateStr = info.getYyjzsj();
					String yydate = infoDateStr.substring(0,10);
					rtn.setAppointTime(yydate);
					String yysj = infoDateStr.substring(11,13);
					int isj = Integer.parseInt(yysj.trim());
					if(isj > 12){
						rtn.setDayRangeType("Afternoon");
					}else{
						rtn.setDayRangeType("morning"); //?
					}
				}
				rtn.setSerialNumber(apply.getYyid());
				rtn.setPatientName(ti(info.getXm()));
				rtn.setPatientIdTypeName("01"); //身份证
				rtn.setPatientIdNumber(info.getSfzh());
				rtn.setPatientAge(String.valueOf(age));
				rtn.setPatientSex(sex);
				rtn.setCurrentMedicalHistory(apply.getXbs()); //现病史
				rtn.setPastHistory(ti(apply.getJws())); //既往史
				rtn.setAllergicHistory(ti("无")); //过敏史
				rtn.setCheckUp(ti(apply.getTgjc())); //体格
				rtn.setAccessoryExam(ti(apply.getFzjc())); //辅助检查
				rtn.setTentativeDiagnosis(ti(apply.getLczd())); //初步诊断
				rtn.setTreatmentProcess(ti(apply.getZlgc()));//治疗过程
				rtn.setMainDoctor(ti(info.getFqysxm()));//主治医生
				rtn.setCosultationPurposeDescription(ti(apply.getHzmd())); //会诊目的
				rtn.setCosultationPurposeProfile("07");
				rtn.setServerDepartmentIds(info.getRjksbh()+",");
			}
		} catch(Throwable t) {
			System.out.println(t.getMessage());
		} 
		return rtn;
	}

	/**
	 * 组织上传的JSON参数
	 * @param info
	 * @return
	 */
	private String organizeCommitJson(HtdBookingInfo info , HtdBookingApply apply) {
		StringBuffer buffer = null;
		int age = -1;
		String sex = null;
		String rtn = null;
		try {
			if(info != null && (!Util.strIsNullOrEmpty(info.getSfzh()))) {
				buffer = new StringBuffer();
				age = IDCardUtil.getAgeBySfzh(info.getSfzh());
				if(age <= 0)
					throw new Exception("从身份证获取年龄信息失败");
				sex = IDCardUtil.getSexBySfzh(info.getSfzh());
				if(Util.strIsNullOrEmpty(sex)) 
					throw new Exception("从身份证获取性别信息失败");
				else if(sex.trim().equals("男"))
					sex = "1";
				else if(sex.trim().equals("女"))
					sex = "2";
				else 
					sex = "0";
				//患者信息
				buffer.append("{");
				buffer.append("\"LOGICNAME\":\"saveConsultation\",").append("\"TOKEN\":\"1\",");
				buffer.append("\"MESSAGEID\":\"1\",");
				buffer.append("\"DATAS\":{");
				buffer.append("\"patientname\":\"").append(info.getXm()).append("\",");	//姓名
				buffer.append("\"idnumber\":\"").append(info.getSfzh()).append("\",");	//身份证
				buffer.append("\"patientage\":\"").append(age).append("\",");	//年龄
				buffer.append("\"patientgender\":\"").append(sex).append("\",");	//性别
				buffer.append("\"emergency\":\"").append("0").append("\",");	//0：非急诊；1：急诊系统默认为0
				if(!Util.strIsNullOrEmpty(info.getYyjzsj())) {
					if(info.getYyjzsj().endsWith(".0"))
						info.setYyjzsj(info.getYyjzsj().substring(0, info.getYyjzsj().length() - 2));
					buffer.append("\"consstart\":\"").append(info.getYyjzsj()).append("\",");	//期望会诊时间
				}
				//病情描述
				buffer.append("\"chiefphysician\":\"").append(info.getFqysxm()).append("\",");	//主治医师
				buffer.append("\"clinmedicalhistory\":\"").append(apply.getXbs()).append("\",");	//现病史
				buffer.append("\"pasthistory\":\"").append(apply.getJws()).append("\",");	//既往史
				buffer.append("\"allergyhistory\":\"").append("无").append("\",");	//过敏史
				buffer.append("\"familyhistory\":\"").append(apply.getJzs()).append("\",");	//家族史
				buffer.append("\"illness\":\"").append(apply.getTgjc()).append("\",");	//体格检查
				buffer.append("\"examination\":\"").append(apply.getFzjc()).append("\",");	//辅助检查
				buffer.append("\"prediagnose\":\"").append(apply.getLczd()).append("\",");	//临床诊断
				buffer.append("\"treatmentprocess\":\"").append(apply.getZlgc()).append("\",");	//治疗过程
				buffer.append("\"reqconsult\":\"").append(apply.getHzmd()).append("\",");	//会诊目的
				//预约信息
				buffer.append("\"isschedule\":\"").append(0).append("\",");	//是否为预约会诊0：非预约；1：预约 系统默认非预约
				buffer.append("\"requserid\":\"").append(RuiJingConfigParam.getRequestid()).append("\",");		//申请人id
				buffer.append("\"reqhospital\":\"").append(info.getFqhospname()).append("\",");	//申请医院名称
				buffer.append("\"reqdepartmentid\":\"").append(info.getRjksbh()).append("\",");	//申请科室ID
				buffer.append("\"reqdepartment\":\"").append(info.getRjksmc()).append("\",");	//申请科室名称
				buffer.append("\"reqsubdeptid\":\"").append(info.getRjchildksbh()).append("\",");	//申请子科室id
				buffer.append("\"reqsubdeptname\":\"").append(info.getRjchildksmc()).append("\",");	//申请子科室名称
				buffer.append("\"reqdoc\":\"").append(info.getFqysxm()).append("\",");		//申请人姓名
				buffer.append("\"consmode\":\"").append("1").append("\",");	//会诊模式  请参考字典表，系统默认为 1
				buffer.append("\"diagtype\":\"").append("clinic").append("\",");		//会诊类型 clinic:临床会诊
				buffer.append("\"consultationtypeid\":\"").append("2").append("\",");	//会诊方式 1:点名会诊  2:非点名会诊
				
				
				
				
				buffer.append("\"assigninfo\":[{");
				buffer.append("\"assignhospitalid\":\"").append(RuiJingConfigParam.getPtrjyybh()).append("\",");		//会诊医院id(瑞金)
				buffer.append("\"assigndepartmentid\":\"").append(info.getRjksbh()).append("\",");		//会诊科室id
				buffer.append("\"assigndocid\":\"").append("").append("\",");		
				buffer.append("\"assigndepttypeid\":\"").append("").append("\",");
				buffer.append("\"assigntriamain\":\"").append("0").append("\"");	//主诊信息；1：主诊，0：非主诊
				buffer.append("}]");
				buffer.append("}");
				buffer.append("}");
				rtn = buffer.toString().replace("\r\n", "");
				rtn = rtn.replace("\r", "");
				rtn = rtn.replace("\n", "");
				rtn = rtn.replace(" ", "");
			}
		} catch(Throwable t) {
			System.out.println(t.getMessage());
		} 
		return rtn;
	}

	/**
	 * 组织上传的JSON参数
	 * @param info
	 * @return
	 */
	private String organizeCancelJson(HtdBookingInfo info) {
		StringBuffer buffer = null;
		String rtn = null;
		try {
			if(info != null && (!Util.strIsNullOrEmpty(info.getRjhzid()))) {
				buffer = new StringBuffer();
				//患者信息
				buffer.append("{");
				buffer.append("\"LOGICNAME\":\"sendCancelConsultation \",").append("\"TOKEN\":\"1\",");
				buffer.append("\"MESSAGEID\":\"1\",");
				buffer.append("\"DATAS\":{");
				buffer.append("\"id\":\"").append(info.getRjhzid()).append("\"");	//瑞金会诊编号
				buffer.append("}");
				buffer.append("}");
				rtn = buffer.toString().replace("\r\n", "");
				rtn = rtn.replace("\r", "");
				rtn = rtn.replace("\n", "");
				rtn = rtn.replace(" ", "");
			}
		} catch(Throwable t) {
			System.out.println(t.getMessage());
		} 
		return rtn;
	}
	
	/**
	 * 调用瑞金接口上传JSON参数
	 * @param inputparam
	 * @return
	 */
	public String commitBookingInfo(String inputparam)
	{
		String rtn = null;
		try {
			rtn = post(RuiJingConfigParam.getHz_service_url() , inputparam);
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		return rtn;
	}
	
	public String commitBookingInfo2(ApplyReq aq){
		String rtn = null;
		String method = "addConsultationApply";
		try {
			String param = generateParams(method, aq);
			String execUrl = RuiJingConfigParam.getHz_service_url2() + method;
			String execParam = param;
			System.out.println("调用上传接口: "+ execUrl);
			System.out.println("调用上传参数: "+ execParam);
			if(true){
			return null;
			}
			rtn = post(execUrl, execParam);  //willtest
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		return rtn;
	}
	
	public String commitBookingInfoTest(ApplyReq aq){
		String rtn = null;
		try {
			String execUrl = "http://39326572.ngrok.io/V1_YCYLRJ/api/addConsultationApply.do";
			String params = "consultationType=clinical&cosultationPurposeProfile=07&thirdSourceUUID=4feeb452-0e69-4651-89d0-95c902d07fde&thirdHospitalName=景德镇市妇幼保健院&serialNumber=d6003033cee44cefac43d4dd849c0eea&consultationWay=general&serverInstiuttionUUID=c8453a37-991a-429d-be1e-4520e729c043&appointTime=2019-04-18&dayRangeType=Afternoon&patientName=马治灵&patientIdTypeName=01&patientIdNumber=360222199512314428&patientAge=24&patientSex=girl&currentMedicalHistory=2016年12月结婚，婚后性生活正常，未避孕，未孕，2019年4月15日行HSG术，插管失败，未注入碘剂。&pastHistory=14岁左右换腮腺炎&allergicHistory=无&checkUp=无&accessoryExam=无&tentativeDiagnosis=原发不孕症&treatmentProcess=无&mainDoctor=医生&cosultationPurposeDescription=给予进一步诊疗建议，特申请徐步芳主任会诊。&serverDepartmentIds=c88602b3-8e0b-4715-9570-8ddfb10ef6f3";
			
			//execUrl = execUrl +".do?"+ params;
			//rtn = post(execUrl, params);  //willtest
			rtn = post(execUrl + "?" + params, "");
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		return rtn;
	}
	
	public String cancelBookingInfo2(HtdBookingInfo info){
		String rtn = null;
		String method = "cancelConsultationApply.do";
		try {
			String param = method + "?thirdApplyId=" + info.getRjhzid();
			String execUrl = RuiJingConfigParam.getHz_service_url2() + param;
			System.out.println("调用取消接口: "+ execUrl);
			rtn = post(execUrl, "");
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		return rtn;
	}

	private String generateParams(String method, ApplyReq aq) {
		// TODO Auto-generated method stub
		String rtn = null;
		StringBuffer buff = new StringBuffer();
		//buff.append(method).append("?");
		buff.append("consultationType=").append(aq.getConsultationType());
		buff.append("&cosultationPurposeProfile=").append(aq.getCosultationPurposeProfile());
		//buff.append("&ThirdSourceId=").append(aq.getThirdSourceId());
		//buff.append("&thirdApplyId=").append(aq.getThirdApplyId());
		buff.append("&thirdSourceUUID=").append(aq.getThirdSourceUUID());
		buff.append("&thirdHospitalName=").append(aq.getThirdHospitalName());
		buff.append("&serialNumber=").append(aq.getSerialNumber());
		buff.append("&consultationWay=").append(aq.getConsultationWay());
		//buff.append("&serverInstiuttionId=").append(aq.getServerInstiuttionId());
		buff.append("&serverInstiuttionUUID=").append(aq.getServerInstiuttionUUID());
		buff.append("&appointTime=").append(aq.getAppointTime());
		buff.append("&dayRangeType=").append(aq.getDayRangeType());
		buff.append("&patientName=").append(aq.getPatientName());
		buff.append("&patientIdTypeName=").append(aq.getPatientIdTypeName());
		buff.append("&patientIdNumber=").append(aq.getPatientIdNumber().toUpperCase());
		buff.append("&patientAge=").append(aq.getPatientAge());
		buff.append("&patientSex=").append(aq.getPatientSex());
		
		buff.append("&currentMedicalHistory=").append(aq.getCurrentMedicalHistory());
		buff.append("&pastHistory=").append(aq.getPastHistory());
		buff.append("&allergicHistory=").append(aq.getAllergicHistory());
		buff.append("&checkUp=").append(aq.getCheckUp());
		buff.append("&accessoryExam=").append(aq.getAccessoryExam());
		buff.append("&tentativeDiagnosis=").append(aq.getTentativeDiagnosis());
		buff.append("&treatmentProcess=").append(aq.getTreatmentProcess());
		buff.append("&mainDoctor=").append(aq.getMainDoctor());
		buff.append("&cosultationPurposeDescription=").append(aq.getCosultationPurposeDescription());
		buff.append("&serverDepartmentIds=").append(aq.getServerDepartmentIds());
		buff.append("&attachStr=").append("{\"imageExamAttachs\":[],\"ecgAttachs\":[],\"pathologyAttachs\":[],\"checkDiagnosticAttachs\":[],\"otherAttachs\":[],\"eusAttachs\":[]}");
		rtn = buff.toString();
		return rtn;
	}

	public String post(String path,String params) throws Exception{
		 HttpURLConnection httpConn=null;
		 BufferedReader in=null;
		 URL url = null;
		 PrintWriter ot = null;
		 StringBuffer content = null;
		 try {
			 url=new URL(path);
			 content=new StringBuffer();
			 httpConn=(HttpURLConnection)url.openConnection();
			 httpConn.setRequestMethod("POST");
			 httpConn.setRequestProperty("APP_ID", "sh_rj");
			 httpConn.setRequestProperty("APP_KEY", "d075ab0d520255c4c241bf2c17268f50");
			 httpConn.setRequestProperty("Accept-Charset", "utf-8");
			 httpConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
			 httpConn.setDoInput(true);
			 httpConn.setDoOutput(true);
			 //utf-8
			 ot = new PrintWriter(new OutputStreamWriter(httpConn.getOutputStream(),"utf-8"));
			 ot.write(params);
			 //ot.println(params);
			 ot.flush();
			 //读取响应
			 if(httpConn.getResponseCode()==HttpURLConnection.HTTP_OK){
				 String tempStr="";
				 //utf-8
				 in=new BufferedReader(new InputStreamReader(httpConn.getInputStream(),"utf-8"));
				 while((tempStr=in.readLine())!=null){
					 content.append(tempStr);
				 }
				 return content.toString();
			 }else{
				 System.out.println("ErrorCode: " + httpConn.getResponseCode());
				 throw new Exception("请求出现了问题!");
			 }
		 } catch (IOException e) {
			 e.printStackTrace();
		 }finally{
			 if(in != null)
				 in.close();
			 if(ot != null)
				 ot.close();
			 httpConn.disconnect();
		 }
		 return content.toString();
	}
	
	/**
	 * 解析接口返回值
	 * @param outparam
	 * @return
	 */
	public RuiJingSaveConsultationRtn analyBookingRtn(String outparam) {
		RuiJingSaveConsultationRtn rtn = null;
		JsonParser parser = null;
		JsonObject object = null;
		try {
			rtn = new RuiJingSaveConsultationRtn();
			rtn.setOutput(outparam);
			parser = new JsonParser();  //创建JSON解析器
			object = (JsonObject) parser.parse(outparam);  //创建JsonObject对象
			rtn.setCode(object.get("code").getAsString());
			rtn.setMsg(object.get("message").getAsString());
			object = (JsonObject) parser.parse(object.get("datas").toString());
			rtn.setRjhzid(object.get("id").getAsString());
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		} 
		return rtn;
	}
	
	public RuiJingSaveConsultationRtn analyBookingRtnNew2(String outparam) {
		RuiJingSaveConsultationRtn rtn = null;
		JsonParser parser = null;
		JsonObject object = null;
		try {
			rtn = new RuiJingSaveConsultationRtn();
			rtn.setOutput(outparam);
			parser = new JsonParser();  //创建JSON解析器
			object = (JsonObject) parser.parse(outparam);  //创建JsonObject对象
			rtn.setCode(object.get("code").getAsString());
			rtn.setMsg(object.get("message").getAsString());
			String rtnentity = object.get("entity").getAsString();
			String rjhzid = "";
			if(rtnentity.indexOf(":") > -1){
				rjhzid = rtnentity.split(":")[1].replaceAll("\"", "").replace("}", "").trim();
			}
			rtn.setRjhzid(rjhzid);
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		} 
		return rtn;
	}
	
	public RuiJingSaveConsultationRtn analyCancelBookingRtn(String outparam) {
		RuiJingSaveConsultationRtn rtn = null;
		JsonParser parser = null;
		JsonObject object = null;
		try {
			rtn = new RuiJingSaveConsultationRtn();
			rtn.setOutput(outparam);
			parser = new JsonParser();  //创建JSON解析器
			object = (JsonObject) parser.parse(outparam);  //创建JsonObject对象
			rtn.setCode(object.get("code").getAsString());
			rtn.setMsg(object.get("message").getAsString());
		} catch(Throwable t) {
			System.out.println(t.getMessage());
			t.printStackTrace();
		} 
		return rtn;
	}

	public void cancelConsultation(Connection conn) throws Exception {
		int total = 0;			//总待上传记录数
		int success = 0;		//上传成功的记录数
		int fail = 0;			//上传失败的记录数
		String sysSt = null;	//接口开始时间，打印日志使用
		String sysEt = null;	//接口完成时间，打印日志使用
		String st = null;		//当天日期  yyyy-mm-dd 00:00:00
		IRuiJingDAO dao = null;	//瑞金的dao
		List<HtdBookingInfo> cancellist = null;	//预约信息
		try {
			dao = DomainDAOFactory.getRuiJingDAO();
			sysSt = DBUtils.getSysdateMySQL(conn , 1);
			System.out.println(sysSt + " 开始上传取消的申请");
			st = DBUtils.getSysdateMySQL(conn, 3);
			//获取取消的申请清单
			cancellist = dao.queryCancelBookingInfo(conn, st);
			if(cancellist == null)
				 throw new Exception("查询瑞金需要取消的会诊失败");
			//循环所有会诊申请
			total = cancellist.size();
			for(int i=0; i<cancellist.size(); i++) {
				String inputparam = "";		//瑞金接口输入参数
				String restfulrtn = null;	//瑞金接口返回值
				RuiJingSaveConsultationRtn restful = null; 	//解析瑞金返回值 
				HtdBookingInfo info = cancellist.get(i);
				//组织格式
				inputparam = organizeCancelJson(info);
				System.out.println(inputparam);
				//调用瑞金服务
				//restfulrtn = commitBookingInfo(inputparam);
				restfulrtn = cancelBookingInfo2(info);
				
				//更新本地表
				restful = analyCancelBookingRtn(restfulrtn);
				System.out.println(restfulrtn);
				//更新本地日志表上传字段
				if(restful.getCode().equals("SUCCESS"))
					dao.updateRuiJingCommitLogStatus(conn, info.getRjhzid(), 0);
				else
					throw new RuntimeException(restful.getMsg());
				success++;
			}
		} catch(Throwable t) {
			fail++;
			System.out.println(t.getMessage());
		} finally {
			sysEt = DBUtils.getSysdateMySQL(conn , 1);
			System.out.println(sysEt + " 结束取消的申请上传：总条数=" + total + "，成功=" + success + "，失败=" + fail);
		}
	}
	
	public String ti(String str){
		//return URLEncoder.encode(str);
		return str;
	}
	
	public static void main(String args[]) {

	}	
}
