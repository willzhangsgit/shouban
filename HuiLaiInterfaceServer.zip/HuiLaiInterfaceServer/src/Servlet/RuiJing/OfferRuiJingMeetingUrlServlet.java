package Servlet.RuiJing;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import clinic.utils.Util;

public class OfferRuiJingMeetingUrlServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4007578643959835132L;

	/**
	 * Constructor of the object.
	 */
	public OfferRuiJingMeetingUrlServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request , response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//http://127.0.0.1:8080/SogoInterface/servlet/OfferRuiJingMeetingUrlServlet?patid=123142143
		//http://115.28.214.242:9998/SogoInterface/servlet/OfferRuiJingMeetingUrlServlet?patid=123142143
		System.out.println("OfferRuiJingMeetingUrlServlet start");
		String rtn = null;			//返回值
		BufferedWriter bw = null;
		String patid = null;
		try {
			//初始化
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			patid = request.getParameter("patid");
			if(Util.strIsNullOrEmpty(patid))
				throw new Exception("patid缺失或值为空");
			//组织返回值
			rtn = "{\"rtnCode\":\"1\",\"url\":\"http://127.0.0.1:63457/?portal=tm.sunpa.com&username=x01&password=0&amp;timestamp=" + System.currentTimeMillis() + "\"}";
		} catch(Exception e) {
			rtn = "{\"rtnCode\":\"-1\",\"msg\":\"" + e.getMessage() + "\"}";
			e.printStackTrace();
		} finally {
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
