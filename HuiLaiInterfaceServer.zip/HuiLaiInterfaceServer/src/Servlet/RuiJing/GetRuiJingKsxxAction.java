package Servlet.RuiJing;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import DAO.IRuiJingDAO;
import Domain.RuiJingDomain;
import clinic.entity.ruijing.HtdRjKsxxNew2;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.factory.DomainDAOFactory;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;

public class GetRuiJingKsxxAction extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2142953565464637157L;
	
	/**
	 * Constructor of the object.
	 */
	public GetRuiJingKsxxAction() {
		super();
	}
	
	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}
	
	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//this.doPost(request, response);
		this.doPostNew(request, response);
	}
	
	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RuiJingDomain rj_domain = null;
		StringBuffer buff = null;
		String rtn = null;
		BufferedWriter bw = null;
		try {
			BaseEntity.SetRuiJingConfigParam();
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=UTF-8");
			rj_domain = new RuiJingDomain();
			buff = new StringBuffer();
			buff.append("{\"LOGICNAME\":\"getAssignDepartment\",\"TOKEN\":\"token\",\"MESSAGEID\":\"uuid\",");
			buff.append("\"DATAS\":{\"hospitalid\":\"").append(RuiJingConfigParam.getPtrjyybh()).append("\"}}");
			rtn = rj_domain.post(RuiJingConfigParam.getHz_service_url() , buff.toString());
			changeJson(rtn);

		} catch(Exception e) {
			rtn = null;
			request.setAttribute("errmsg", e.getMessage());
			e.printStackTrace();
		} finally {
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}
	
	private void changeJson(String output) throws Exception {
		JsonParser parser = null;
		JsonObject object = null;
		JsonArray array = null;
		try {
			parser = new JsonParser();
			object = (JsonObject) parser.parse(output);
			object = (JsonObject) parser.parse(object.get("datas").toString());
			System.out.println(object.toString());
			array = object.getAsJsonArray("list");
			for(int i=0; i<array.size(); i++) {
				JsonObject ks = null;
				ks = (JsonObject) parser.parse(array.get(i).toString());
				System.out.println(ks.get("DEPARTMENT_NAME").getAsString());
				//DEPARTMENTID
			}
		} catch(Exception e) {
			throw new Exception(e.getMessage());
		}
	}
	
	public void doPostNew(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RuiJingDomain rj_domain = null;
		StringBuffer buff = null;
		String rtn = null;
		BufferedWriter bw = null;
		try {
			BaseEntity.SetRuiJingConfigParam();
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=UTF-8");
			rj_domain = new RuiJingDomain();
			buff = new StringBuffer();
			rtn = rj_domain.post(RuiJingConfigParam.getHz_service_url2() +"pageDepartment?hospitalUUID=c8453a37-991a-429d-be1e-4520e729c043", buff.toString());  //瑞金医院id为1
			changeJsonNew(rtn);
		} catch(Exception e) {
			rtn = null;
			request.setAttribute("errmsg", e.getMessage());
			e.printStackTrace();
		} finally {
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}
	
	private void changeJsonNew(String output) throws Exception {
		JsonParser parser = null;
		JsonObject object = null;
		JsonArray array = null;
		Connection conn = null;
		IRuiJingDAO dao = null;	//鐟為噾鐨刣ao
		try {
			parser = new JsonParser();
			object = (JsonObject) parser.parse(output);
			//object = (JsonObject) parser.parse(object.get("code").toString());
			//System.out.println(object.toString());
			array = object.getAsJsonArray("entity");
			for(int i=0; i<array.size(); i++) {
				JsonObject ks = null;
				ks = (JsonObject) parser.parse(array.get(i).toString());
				System.out.println(ks.get("name").getAsString());
				//DEPARTMENTID
				conn = DBUtils.GetConn();
				dao = DomainDAOFactory.getRuiJingDAO();
				HtdRjKsxxNew2 ksxx = getKsxx(ks);
				String ourid = getOurid(conn, dao, ks.get("name").getAsString());
				dao.insertRuiJingKsxx(conn,ksxx, ourid);
			}
		} catch(Exception e) {
			throw new Exception(e.getMessage());
		}finally{
			DBUtils.closeConn(null, null, conn);
		}
		
	}

	private String getOurid(Connection conn, IRuiJingDAO dao, String name) {
		// TODO Auto-generated method stub
		String rtn = dao.queryRuiJingOurid(conn, name);
		return rtn;
	}

	private HtdRjKsxxNew2 getKsxx(JsonObject ks) {
		// TODO Auto-generated method stub
		HtdRjKsxxNew2 rtn = new HtdRjKsxxNew2();
		rtn.setHOSPITAL_ID("c8453a37-991a-429d-be1e-4520e729c043");//瑞金
		rtn.setRjKsid(ks.get("id").getAsString());
		rtn.setRjKsbh(ks.get("uuid").getAsString());
		rtn.setRjKsmc(ks.get("name").getAsString());
		if(ks.get("parentId").isJsonNull())
			rtn.setPARENT_ID("-1");
		else
			rtn.setPARENT_ID(ks.get("parentId").getAsString());
		
		rtn.setDESCRIPTION(ks.get("description").getAsString());
		return rtn;
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
