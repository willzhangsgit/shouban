package Servlet.Cnmia;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import DAO.ICnmiaDAO;
import clinic.factory.DomainDAOFactory;
import clinic.utils.DBUtils;

public class WriteMeetingRoomAction extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9125065964596042299L;

	/**
	 * Constructor of the object.
	 */
	public WriteMeetingRoomAction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String room = null;
		String serialno = null;
		Connection conn = null;
		ICnmiaDAO dao = null;
		HttpSession session = null;
		try {
			//初始化
			path = request.getContextPath();
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			session = request.getSession(); 
			room = request.getParameter("room");
			serialno = request.getParameter("serialno");
			//获取数据连接
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			dao = DomainDAOFactory.getCnmiaDAO();
			//回写数据库
			dao.writeMeetingRoom(conn, room, serialno);
			DBUtils.Commit(conn);
			session.setAttribute("room", room);
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			request.setAttribute("errmsg", e.getMessage());
			response.sendRedirect(path + "/error.jsp");
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
