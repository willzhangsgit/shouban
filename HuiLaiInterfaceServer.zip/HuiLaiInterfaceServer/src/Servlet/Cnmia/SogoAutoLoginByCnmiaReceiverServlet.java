package Servlet.Cnmia;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;
import DAO.ICnmiaDAO;
import clinic.entity.Cnmia.CnmiaConfigParam;
import clinic.factory.DomainDAOFactory;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.HttpUtil;
import clinic.utils.JasonParamUtil;
import clinic.utils.Util;

public class SogoAutoLoginByCnmiaReceiverServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5030884167130805599L;

	/**
	 * Constructor of the object.
	 */
	public SogoAutoLoginByCnmiaReceiverServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request , response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String rtnUrl = null;
		String rtn = null;
		String loginname = null;	//登录用户名
		String sqdh = null;			//非公单据唯一编号
		String yyid = null;			//我们的YYID
		String pid = null;			//我们患者PID
		String jsonParam = null;	//传过来的参数
		Connection conn = null;
		HttpSession session = null;
		ICnmiaDAO dao = null;
		JSONObject jsonObj = null;
		BufferedWriter bw = null;
		try {
			//http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByCnmiaReceiverServlet?sqdh=1asdfasdf&yyid=aasdfasdrwqer
			//http://115.28.214.242:9998/SogoInterface/servlet/SaveCnmiaBookingInfoServlet?sqdh=1asdfasdf&yyid=111212312
			//http://www.allhealth.com.cn:8199/framework/allhealth/consultation_queue.do?yzxzbyy&
			BaseEntity.SetCnmiaConfigParam();
			//获取网页参数
			path = request.getContextPath();
			session = request.getSession(); 
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			//获取参数
			jsonParam = HttpUtil.acceptParam(request);
			if(Util.strIsNullOrEmpty(jsonParam))
				throw new Exception("参数为空");
			//类型转换
			jsonObj = JasonParamUtil.strToJsonObject(jsonParam);
			//解析参数
			loginname = JasonParamUtil.getJasonStringValue(jsonObj, "loginname", null, true);
			sqdh = JasonParamUtil.getJasonStringValue(jsonObj, "sqdh", null, true);
			//初始化DAO和获取数据库连接
			dao = DomainDAOFactory.getCnmiaDAO();
			conn = DBUtils.GetConn();
			//获取我们申请单信息
			yyid = dao.queryYyidByCnmyyid(conn, sqdh);
			if(Util.strIsNullOrEmpty(yyid))
				throw new Exception("根据非公的SQDH没有找到我们的YYID");
			//获取病人PID
			pid = dao.queryPidByYyid(conn, yyid);
			if(Util.strIsNullOrEmpty(pid))
				throw new Exception("没有找到病人PID记录");
			//组织URL
			rtnUrl = CnmiaConfigParam.getReceiver_autologin_url() + "?loginsource=1ychz&username=" + loginname + "&pass=111111&pid=" + pid + "&yyid=" + yyid;
			System.out.println(rtnUrl);
			rtn = "{\"rtnCode\":\"1\",\"errmsg\":\"\",\"url\":\"" + rtnUrl + "\"}";
			System.out.println(rtn);
			//response.sendRedirect(rtnUrl);
		} catch(Exception e) {
			if(e.getMessage() == null)
				rtn = "{\"rtnCode\":\"-1\",\"errmsg\":\"\",\"url\":\"\"}";
			else
				rtn = "{\"rtnCode\":\"-1\",\"errmsg\":\"" + e.getMessage() + "\",\"url\":\"\"}";
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
