package Servlet.Cnmia;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONObject;
import DAO.ICnmiaDAO;
import DAO.IHuiLaiDAO;
import clinic.entity.Cnmia.CnmiaConfigParam;
import clinic.entity.HuiLai.HtdPatientInfo;
import clinic.factory.DomainDAOFactory;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.HttpUtil;
import clinic.utils.JasonParamUtil;
import clinic.utils.Util;

public class SogoAutoLoginByCnmiaInitiatorServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6941955972354227773L;

	/**
	 * Constructor of the object.
	 */
	public SogoAutoLoginByCnmiaInitiatorServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request , response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String rtnUrl = null;
		String rtn = null;
		String brxm = null;		//病人姓名
		String brxb = null;		//病人性别
		String sfzh = null;		//身份证号
		String lxdh = null;		//联系电话
		String loginname = null;	//登录账号
		String ycyybh = null;	//远程医院编号(你们医院编号)
		String ycyymc = null;	//远程医院名称
		String ycksbh = null;	//远程科室编号（你们该医院下面的科室编号）
		String ycksmc = null;	//远程科室名称
		String fqyybh = null;	//发起医院编号(你们医院编号)
		String fqyymc = null;	//发起医院名称
		String fqksbh = null;	//发起科室编号（你们该医院下面的科室编号）
		String fqksmc = null;	//发起科室名称
		String qsrq = null;		//期望会诊日期
		String sqdh = null;		//申请单据号
		String pid = null;		//我们病人唯一编号
		String yyid = null;		//我们的预约ID
		String jsonParam = null;	//传过来的参数
		Connection conn = null;
		HttpSession session = null;
		ICnmiaDAO cnmiaDao = null;
		IHuiLaiDAO hlDao = null;
		JSONObject jsonObj = null;
		HtdPatientInfo patinfo = null;
		BufferedWriter bw = null;
		try {
			BaseEntity.SetCnmiaConfigParam();
			//获取网页参数
			path = request.getContextPath();
			session = request.getSession(); 
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			//获取参数
			jsonParam = HttpUtil.acceptParam(request);
			if(Util.strIsNullOrEmpty(jsonParam))
				throw new Exception("参数为空");
			//类型转换
			jsonObj = JasonParamUtil.strToJsonObject(jsonParam);
			//解析参数
			brxm = JasonParamUtil.getJasonStringValue(jsonObj, "brxm", null, true);
			brxb = JasonParamUtil.getJasonStringValue(jsonObj, "brxb", null, true);
			sfzh = JasonParamUtil.getJasonStringValue(jsonObj, "sfzh", null, true);
			lxdh = JasonParamUtil.getJasonStringValue(jsonObj, "lxdh", null, true);
			loginname = JasonParamUtil.getJasonStringValue(jsonObj, "loginname", null, true);
			ycyybh = JasonParamUtil.getJasonStringValue(jsonObj, "ycyybh", "", false);
			ycyymc = JasonParamUtil.getJasonStringValue(jsonObj, "ycyymc", "", false);
			ycksbh = JasonParamUtil.getJasonStringValue(jsonObj, "ycksbh", "", false);
			ycksmc = JasonParamUtil.getJasonStringValue(jsonObj, "ycksmc", "", false);
			fqyybh = JasonParamUtil.getJasonStringValue(jsonObj, "fqyybh", "", false);
			fqyymc = JasonParamUtil.getJasonStringValue(jsonObj, "fqyymc", "", false);
			fqksbh = JasonParamUtil.getJasonStringValue(jsonObj, "fqksbh", "", false);
			fqksmc = JasonParamUtil.getJasonStringValue(jsonObj, "fqksmc", "", false);
			qsrq = JasonParamUtil.getJasonStringValue(jsonObj, "qsrq", "", false);
			sqdh = JasonParamUtil.getJasonStringValue(jsonObj, "sqdh", null, true);
			//初始化DAO和获取数据库连接
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			cnmiaDao = DomainDAOFactory.getCnmiaDAO();
			hlDao = DomainDAOFactory.getHuiLaiDAO();
			//判断病人信息是否存在  SELECT * FROM HUILAI.HTD_PATIENT_INFO
			if(!hlDao.existsPatInfo(conn, sfzh)) {//存在病人
				patinfo = setPatInfo(brxm , brxb , sfzh , lxdh);
				pid = hlDao.createPatInfo(conn, patinfo);
			} else 
				patinfo = hlDao.queryPatInfo(conn, sfzh);
			pid = patinfo.getPid();
			//获取我们的YYID
			yyid = cnmiaDao.queryYyidByCnmyyid(conn, sqdh);
			//组织URL
			rtnUrl = CnmiaConfigParam.getInitiator_autologin_url() + "?loginsource=1ycmz&username=" + loginname + "&pass=111111&yyid=" + yyid + "&pid=" + pid + "&sfzh=" + patinfo.getSfzh() + "&sqdh=" + sqdh;
			System.out.println(rtnUrl);
			rtn = "{\"rtnCode\":\"1\",\"errmsg\":\"\",\"url\":\"" + rtnUrl + "\"}";
			System.out.println(rtn);
			DBUtils.Commit(conn);
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			if(e.getMessage() == null)
				rtn = "{\"rtnCode\":\"-1\",\"errmsg\":\"\",\"url\":\"\"}";
			else
				rtn = "{\"rtnCode\":\"-1\",\"errmsg\":\"" + e.getMessage() + "\",\"url\":\"\"}";
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}
	
	/**
	 * 设置病人信息
	 * @param xm
	 * @param xb
	 * @param sfzh
	 * @param sjh
	 * @return
	 * @throws Exception
	 */
	public HtdPatientInfo setPatInfo(String xm , String xb , String sfzh , String sjh) throws Exception{
		HtdPatientInfo pat = null;
		try {
			pat = new HtdPatientInfo();
			pat.setXm(xm);
			if(xb.equals("男"))
				pat.setXb("M");
			else if(xb.equals("女"))
				pat.setXb("F");
			else
				pat.setXb("N");
			pat.setSfzh(sfzh);
			pat.setSjh(sjh);
		} catch(Exception ex) {
			throw new Exception(ex.getMessage());
		}
		return pat;
	}
}
