package Servlet.Cnmia;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import clinic.entity.Cnmia.CnmiaMeetingInfo;
import clinic.entity.Cnmia.CnmiaUserInfo;
import clinic.factory.DomainDAOFactory;
import clinic.utils.DBUtils;
import DAO.ICnmiaDAO;

public class GetVideoParamAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3226515999846825778L;

	/**
	 * Constructor of the object.
	 */
	public GetVideoParamAction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String room = null;
		String serialno = null;
		Connection conn = null;
		ICnmiaDAO dao = null;
		CnmiaUserInfo user = null;
		CnmiaMeetingInfo meetinfo = null;
		HttpSession session = null;
		try {
			//初始化
			path = request.getContextPath();
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			session = request.getSession(); 
			room = request.getParameter("room");
			serialno = request.getParameter("serialno");
			//获取数据连接
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			dao = DomainDAOFactory.getCnmiaDAO();
			//查询用户
			user = dao.queryMeetingUser(conn, "DAK344a1af47091460eaf9acb0aa616655b");
			//查询会议参数信息
			meetinfo = dao.queryMeetingInfo(conn, serialno);
			//如果会议室为0，数据库判断是否有匹配的会议室
			room = dao.queryMeetingRoomBySerialno(conn, serialno);
			DBUtils.Commit(conn);
			//设置request和跳转
			session.setAttribute("room", room);
			session.setAttribute("serialno", serialno);
			session.setAttribute("user", user);
			session.setAttribute("meet", meetinfo);
			response.sendRedirect(path + "/cnima/SogoKandyVideo.jsp");
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			request.setAttribute("errmsg", e.getMessage());
			response.sendRedirect(path + "/error.jsp");
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
