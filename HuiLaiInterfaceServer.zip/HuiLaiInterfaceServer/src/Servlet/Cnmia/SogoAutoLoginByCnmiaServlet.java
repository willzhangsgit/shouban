package Servlet.Cnmia;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import clinic.entity.Cnmia.CnmiaConfigParam;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.Util;

public class SogoAutoLoginByCnmiaServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4512896436781077808L;

	/**
	 * Constructor of the object.
	 */
	public SogoAutoLoginByCnmiaServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request , response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String loginname = null;
		String rtnUrl = null;
		Connection conn = null;
		HttpSession session = null;
		try {
			//http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByCnmiaServlet?loginname=yzxzbyy
			//http://www.allhealth.com.cn:8199/framework/allhealth/autologin?username=yxtmz&pass=111111&loginsource=Cnmia
			//http://115.28.214.242:9998/SogoInterface/servlet/SogoAutoLoginByCnmiaServlet?loginname=yxtmz
			BaseEntity.SetCnmiaConfigParam();
			//获取网页参数
			path = request.getContextPath();
			session = request.getSession(); 
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			loginname = request.getParameter("loginname");	//用户登录名
			if(Util.strIsNullOrEmpty(loginname))
				throw new Exception("登录名不能为空");
			//返回自动登录URL
			rtnUrl = CnmiaConfigParam.getAutologin_url() + "?username=" + loginname + "&pass=" + "111111" + "&loginsource=Cnmia";
			System.out.println(rtnUrl);
			response.sendRedirect(rtnUrl);
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			session.setAttribute("errmsg", e.getMessage());
			response.sendRedirect(path + "/error.jsp");
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
