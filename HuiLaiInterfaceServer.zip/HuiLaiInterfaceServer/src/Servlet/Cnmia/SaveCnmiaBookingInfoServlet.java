package Servlet.Cnmia;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.ICnmiaDAO;
import clinic.factory.DomainDAOFactory;
import clinic.utils.DBUtils;

public class SaveCnmiaBookingInfoServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3362829297637805316L;

	/**
	 * Constructor of the object.
	 */
	public SaveCnmiaBookingInfoServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request , response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//http://127.0.0.1:8080/SogoInterface/servlet/SaveCnmiaBookingInfoServlet?sqdh=1asdfasdf&yyid=aasdfasdrwqer
		//http://115.28.214.242:9998/SogoInterface/servlet/SaveCnmiaBookingInfoServlet?sqdh=1asdfasdf&yyid=111212312
		String rtnUrl = null;
		String sqdh = null;		//非公单据唯一编号
		String yyid = null;		//我们单据唯一编号
		Connection conn = null;
		ICnmiaDAO dao = null;
		try {
			//BaseEntity.SetCnmiaConfigParam();
			//获取网页参数
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			//获取参数
			sqdh = request.getParameter("sqdh");
			yyid = request.getParameter("yyid");
			//初始化DAO和获取数据库连接
			dao = DomainDAOFactory.getCnmiaDAO();
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			//判断是否存在sqdh
			if(dao.existsYyinfo(conn, sqdh))
				dao.updateYyinfo(conn, sqdh, yyid);
			else
				dao.addYyinfo(conn, sqdh, yyid);
			DBUtils.Commit(conn);
			response.sendRedirect(rtnUrl);
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
