package Servlet.XueTouTong;

import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import DAO.IXueTouTongDAO;
import clinic.entity.XueTouTong.XueTouTongConfigParam;
import clinic.factory.DomainDAOFactory;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;
import clinic.utils.Util;

public class SogoAutoLoginByXttService extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8285114606277197435L;

	/**
	 * Constructor of the object.
	 */
	public SogoAutoLoginByXttService() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = null;
		String loginname = null;
		String username = null;
		String cookie_token = null;
		String rtnUrl = null;
		String result = null;
		Connection conn = null;
		IXueTouTongDAO dao = null;
		HttpSession session = null;
		try {
			//http://www.allhealth.com.cn:8199/framework/allhealth/autologin?username=sgadmin&pass=111111
			//http://127.0.0.1:8080/SogoInterface/servlet/SogoAutoLoginByXttService?loginname=sgtest&username=sgtestname&cookie_token=1212222
			//http://www.allhealth.com.cn:8199/framework/allhealth/autologin?username=SG_TEST231&pass=111111&loginsource=XueTouTong
			BaseEntity.SetXueTouTongConfigParam();
			//获取网页参数
			path = request.getContextPath();
			session = request.getSession(); 
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			loginname = request.getParameter("loginname");	//用户登录名
			if(Util.strIsNullOrEmpty(loginname))
				throw new Exception("登录名不能为空");
			//username = new String(request.getParameter("username").getBytes("ISO-8859-1"), "UTF-8");	//用户姓名
			//username = new String(username.getBytes("ISO-8859-1"), "UTF-8");	//用户姓名
			//username = URLEncoder.encode(request.getParameter("username"), "UTF-8"); //一次转码 （获取的是：%E6%B5%8B%E8%AF%95）  
			username = URLDecoder.decode(request.getParameter("username"), "UTF-8");//二次转码（获取为 中文）  
			if(Util.strIsNullOrEmpty(username))
				throw new Exception("用户名不能为空");
			cookie_token = request.getParameter("cookie_token");	//token
			if(Util.strIsNullOrEmpty(cookie_token))
				throw new Exception("TOKEN不能为空");
			//初始化
			conn = DBUtils.GetConn();
			DBUtils.BeginTrans(conn);
			dao = DomainDAOFactory.getXueTouTongDAO();
			//调用存储过程判断用户是否存、自动添加用户、权限、医院、部门等信息
			//不管是新增用户还是原来用户，由于密码不可逆查询到，所有密码都会置成111111
			result = dao.addUserInfo(conn, loginname , username, cookie_token);
			if(!result.equals("1"))
				throw new Exception("添加用户名失败");
			DBUtils.Commit(conn);
			//返回自动登录URL
			rtnUrl = XueTouTongConfigParam.getSogo_xtt_autologin_url() + "?username=" + loginname + "&pass=" + "111111" + "&loginsource=XueTouTong";
			System.out.println(rtnUrl);
			response.sendRedirect(rtnUrl);
		} catch(Exception e) {
			DBUtils.RollBack(conn);
			session.setAttribute("errmsg", e.getMessage());
			response.sendRedirect(path + "/error.jsp");
			e.printStackTrace();
		} finally {
			DBUtils.closeConn(null, null, conn);
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
