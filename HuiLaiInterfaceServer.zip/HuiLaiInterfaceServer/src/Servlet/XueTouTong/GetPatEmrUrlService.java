package Servlet.XueTouTong;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import clinic.entity.XueTouTong.XueTouTongConfigParam;
import clinic.utils.BaseEntity;
import clinic.utils.Util;

public class GetPatEmrUrlService extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4671153595583016566L;

	/**
	 * Constructor of the object.
	 */
	public GetPatEmrUrlService() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//调用的URL:http://www.allhealth.com.cn:9998/SogoInterface/servlet/GetXueTouTongPatEmrUrlService?sfzh=310115198210253815
		String sfzh = null;
		String rtnUrl = null;
		BufferedWriter bw = null;
//		IXueTouTongDAO dao = null;
//		Connection conn = null;
		String rtn = null;
		try {
			BaseEntity.SetXueTouTongConfigParam();
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html; charset=utf-8");
			sfzh = request.getParameter("sfzh");
			if(Util.strIsNullOrEmpty(sfzh))
				throw new Exception("身份证不能为空");
//			if(!Util.strIsNullOrEmpty(IDCardUtil.Verify(sfzh)))
//				throw new Exception("身份证号码不正确");
//			dao = DomainDAOFactory.getXueTouTongDAO();
//			conn = DBUtils.GetConn();
			//获取最新的学透通token
			//token = dao.queryXueTouTongToken(conn);
			//rtnUrl = XueTouTongConfigParam.getPat_emr_url() +  "?sfzh=" + sfzh + "&cookie_token=" + token;
			rtnUrl = XueTouTongConfigParam.getPat_emr_url() +  "?sfzh=" + sfzh;
			rtn = "{\"code\":\"1\",\"msg\":\"成功\",\"url\":\"" + rtnUrl + "\"}";
		} catch(Exception e) {
			rtn = "{\"code\":\"-1\",\"msg\":\"" + e.getMessage() + "\",\"url\":\"\"}";
			e.printStackTrace();
		} finally {
//			DBUtils.closeConn(null, null, conn);
			bw = new BufferedWriter(new OutputStreamWriter(response.getOutputStream(),Charset.forName("utf-8")));
			bw.write(rtn);
			bw.flush();
			if(bw != null)
				bw.close();
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
