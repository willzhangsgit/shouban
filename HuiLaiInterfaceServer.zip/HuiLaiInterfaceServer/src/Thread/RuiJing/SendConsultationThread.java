package Thread.RuiJing;

import java.sql.Connection;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import Domain.RuiJingDomain;
import clinic.entity.ruijing.RuiJingConfigParam;
import clinic.utils.BaseEntity;
import clinic.utils.DBUtils;

public class SendConsultationThread extends BaseEntity implements Runnable , ServletContextListener {
	
	public void run()
	{
		while(true) {
			Connection conn = null;
			RuiJingDomain rj_domain = null;
			try {
				BaseEntity.SetRuiJingConfigParam2();
				rj_domain = new RuiJingDomain();
				System.out.println("瑞金平台接口(URL参数)：" + RuiJingConfigParam.getHz_service_url());
				System.out.println("瑞金平台接口(间隔时间)：" + RuiJingConfigParam.getCommit_interval());
				System.out.println("瑞金平台接口(上传符合的预约状态，中心端已经审核)：" + RuiJingConfigParam.getYyzt());
				System.out.println("瑞金平台接口(上传符合的就诊状态，未就诊)：" + RuiJingConfigParam.getJzzt());
				System.out.println("瑞金平台接口(本地瑞金医院编号)：" + RuiJingConfigParam.getBdrjyybh());
				System.out.println("瑞金平台接口(平台上传申请编码，由平台申请提供)：" + RuiJingConfigParam.getRequestid());
				System.out.println("瑞金平台接口(平台瑞金医院编号)：" + RuiJingConfigParam.getPtrjyybh());
				//获取数据库连接（千万不要开启事务，成功上传一条就commit一条，避免平台和本地信息不同步）
				conn = DBUtils.GetConn();
				//上传会诊申请
				rj_domain.sendConsultation(conn);
				//取消上传会诊申请
				rj_domain.cancelConsultation(conn);
			} catch (Throwable t) {
				t.printStackTrace();
			} 	
			finally {
				DBUtils.closeConn(null, null, conn);
				try {
					Thread.sleep(RuiJingConfigParam.getCommit_interval());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
    public void contextInitialized(ServletContextEvent arg0) {
		try {
			SendConsultationThread hzCommitThread = new SendConsultationThread();
			Thread t = new Thread(hzCommitThread);
			t.start();
		} catch (Throwable t) {
			t.printStackTrace();
		} 	
         
    }
	
	@Override
    public void contextDestroyed(ServletContextEvent arg0) {
        // TODO Auto-generated method stub
    }

}